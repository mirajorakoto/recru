const fs = require("node:fs");
const path = require("node:path");
const express = require("express");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const { createRecruitmentModule } = require("./src");
const { createOpenAiService } = require("./src/ai");
const { loadEnvFile, loadConfig, ConfigValidationError } = require("./src/config");

// Explicitly load the repository-root .env before reading any variable.
// Real environment variables (CI, container, hosting platform) always win.
loadEnvFile();

let config;
try {
  config = loadConfig();
} catch (error) {
  if (error instanceof ConfigValidationError) {
    console.error(error.message);
    process.exit(1);
  }
  throw error;
}

const dbPath = config.dbPath;
// A fresh clone does not contain ignored runtime directories.
fs.mkdirSync(path.dirname(dbPath), { recursive: true, mode: 0o700 });
const db = new Database(dbPath);
db.pragma("foreign_keys = ON");
const fileKey = config.fileKey;

// Sans OPENAI_API_KEY dans .env, on garde un analyseur factice déterministe
// (toujours "uncertain") pour que la démo fonctionne hors ligne. Dès qu'une
// vraie clé est présente, on utilise le vrai service OpenAI (même code que
// server.js en production) pour obtenir une analyse qui varie réellement
// selon le contenu de chaque CV.
const demoAiService = {
  model: "demo-deterministic-analyzer",
  async analyzeApplication({ job }) {
    return {
      summary: "Analyse fictive du banc d’essai (aucune clé OPENAI_API_KEY configurée). Vérifiez toujours les documents originaux.",
      criteria: job.criteria.map((item) => ({
        criterion: item.label,
        required: Boolean(item.required),
        assessment: "uncertain",
        evidence: "Banc d’essai: aucune conclusion automatique.",
        source: "none"
      })),
      missing_information: [],
      uncertainties: ["Résultat synthétique de démonstration"],
      recommendation: "uncertain",
      human_review_notice: true
    };
  },
  async draftSelectionEmail({ application, job }) {
    return {
      subject: `Suite favorable à votre candidature — ${job.title}`,
      html: `<p>Bonjour ${application.full_name},</p><p>Votre candidature au poste de <strong>${job.title}</strong> est retenue pour la prochaine étape.</p>`
    };
  }
};

const aiService = config.openai.apiKey
  ? createOpenAiService({
    apiKey: config.openai.apiKey,
    model: config.openai.model,
    timeoutMs: config.openai.timeoutMs
  })
  : demoAiService;

if (config.openai.apiKey) {
  console.log(`[demo] OPENAI_API_KEY détectée : analyse IA réelle activée (modèle ${config.openai.model}).`);
} else {
  console.log("[demo] Pas d'OPENAI_API_KEY : analyse IA factice (toujours \"uncertain\"). Ajoute la clé dans .env pour une vraie analyse.");
}

const moduleInstance = createRecruitmentModule({
  db,
  requireAdminSession(req, res, next) {
    req.adminUser = { id: 1, email: "rh-demo@techzone.lat", display_name: "RH Démo" };
    next();
  },
  transporter: nodemailer.createTransport({ jsonTransport: true }),
  aiService,
  config: {
    storageDir: config.storageDir,
    fileKey,
    retentionDays: config.retentionDays,
    maxFileMb: config.maxFileMb,
    bypassTurnstile: config.turnstile.bypassAllowed,
    smtpFrom: "TECH ZONE Démo <contact@techzone.lat>"
  }
});

if (moduleInstance.repository.listJobs().length === 0) {
  moduleInstance.repository.createJob({
    slug: "stage-developpeur-web",
    title: "Stagiaire développeur web",
    summary: "Contribuez à des produits web utiles avec un accompagnement technique.",
    description: "Vous participerez au développement, aux tests et à la documentation de fonctionnalités web.",
    criteria: [
      { label: "Bases solides en JavaScript", required: true },
      { label: "Capacité à expliquer un projet réalisé", required: true },
      { label: "Connaissance de React", required: false }
    ],
    location: "Fianarantsoa",
    work_mode: "hybrid",
    contract_type: "stage",
    employer_type: "techzone",
    status: "published",
    urgent: true
  });
  moduleInstance.repository.createJob({
    slug: "responsable-operations",
    title: "Responsable opérations",
    summary: "Pilotez les opérations et accompagnez la croissance de nos activités.",
    description: "Vous coordonnerez les équipes opérationnelles et suivrez les indicateurs clés de performance au quotidien.",
    criteria: [
      { label: "Organisation", required: true },
      { label: "Leadership", required: true },
      { label: "Amélioration continue", required: false }
    ],
    location: "Antananarivo",
    work_mode: "onsite",
    contract_type: "cdi",
    employer_type: "partner",
    partner_name: "Partenaire TechZone",
    status: "published",
    urgent: false
  });
  moduleInstance.repository.createJob({
    slug: "support-client",
    title: "Support client",
    summary: "Accompagnez nos utilisateurs et contribuez à leur satisfaction.",
    description: "Vous traiterez les demandes entrantes et assurerez le suivi des dossiers jusqu’à leur résolution.",
    criteria: [
      { label: "Communication", required: true },
      { label: "Résolution de problèmes", required: true },
      { label: "Sens du service", required: false }
    ],
    location: "Antananarivo",
    work_mode: "onsite",
    contract_type: "cdd",
    employer_type: "techzone",
    status: "published",
    urgent: false
  });
}

const app = express();
app.use(express.json({ limit: "1mb" }));
app.get("/api/health", (req, res) => res.json({ ok: true, mode: "recruitment-demo" }));
app.use("/api/recrutement", moduleInstance.publicRouter);
app.use("/api/admin/recrutement", moduleInstance.adminRouter);
app.use((error, req, res, next) => {
  if (error?.code === "LIMIT_FILE_SIZE") return res.status(400).json({ error: "Le fichier dépasse 10 Mo." });
  console.error("Erreur HTTP recrutement du banc d’essai.");
  res.status(500).json({ error: "Erreur serveur du banc d’essai." });
});

const port = config.port;
const server = app.listen(port, "127.0.0.1", () => {
  console.log(`TechZone recruitment demo API: http://127.0.0.1:${port}`);
  moduleInstance.start();
});

function shutdown() {
  moduleInstance.stop();
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
