const { createOpenAiService } = require("./ai");
const { createRepository } = require("./repository");
const { createRouters } = require("./routes");
const { runMigrations } = require("./migrations/runner");
const { getEncryptionKey } = require("./security");
const { createAnalysisWorker, createPurgeScheduler } = require("./worker");

function createRecruitmentModule(options) {
  if (typeof options?.db?.prepare !== "function") throw new Error("A shared better-sqlite3 db adapter is required.");
  if (typeof options?.requireAdminSession !== "function") throw new Error("The host requireAdminSession middleware is required.");
  if (typeof options?.transporter?.sendMail !== "function") throw new Error("A SMTP transporter with sendMail is required.");
  const config = {
    storageDir: options.config?.storageDir,
    maxFileMb: options.config?.maxFileMb || 10,
    retentionDays: options.config?.retentionDays || 180,
    turnstileSecret: options.config?.turnstileSecret,
    bypassTurnstile: options.config?.bypassTurnstile,
    fetchImpl: options.config?.fetchImpl,
    applicationRateLimit: options.config?.applicationRateLimit || 5,
    smtpFrom: options.config?.smtpFrom || "TECH ZONE Recrutement <contact@techzone.lat>"
  };
  if (!config.storageDir) throw new Error("config.storageDir is required.");
  runMigrations(options.db);
  const repository = createRepository(options.db);
  const encryptionKey = getEncryptionKey(options.config.fileKey);
  const aiService = options.aiService || createOpenAiService({
    apiKey: options.config.openAiApiKey,
    model: options.config.openAiModel || "gpt-5.4-nano-2026-03-17",
    timeoutMs: options.config.openAiTimeoutMs
  });
  const routers = createRouters({
    repository,
    config,
    encryptionKey,
    aiService,
    transporter: options.transporter,
    resolveMediaAsset: options.resolveMediaAsset
  });
  const worker = createAnalysisWorker({ repository, aiService, encryptionKey });
  const purgeScheduler = createPurgeScheduler({
    repository,
    retentionDays: config.retentionDays,
    intervalMs: options.config?.purgeIntervalMs
  });
  const adminRouter = require("express").Router();
  adminRouter.use(options.requireAdminSession, routers.adminRouter);

  return {
    adminRouter,
    publicRouter: routers.publicRouter,
    repository,
    runMigrations: () => runMigrations(options.db),
    start: () => {
      purgeScheduler.start();
      worker.start();
    },
    stop: () => {
      worker.stop();
      purgeScheduler.stop();
    },
    worker,
    purgeScheduler
  };
}

module.exports = {
  createRecruitmentModule,
  createRepository,
  runMigrations
};
