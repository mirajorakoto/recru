const fs = require("node:fs");
const express = require("express");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const { randomUUID } = require("node:crypto");
const {
  decryptDocument,
  encryptDocument,
  htmlToText,
  sanitizeEmailHtml,
  validateCandidateDocument,
  verifyTurnstile
} = require("./security");

const CONTRACT_TYPES = new Set(["stage", "cdd", "cdi", "alternance", "freelance", "interim", "autre"]);
const JOB_STATUSES = new Set(["draft", "published", "closed", "archived"]);
const PROCESSING_STATUSES = new Set(["received", "queued", "processing", "analysis_ready", "analysis_failed"]);
const DECISIONS = new Set(["to_review", "selected", "rejected", "withdrawn"]);

function cleanString(value, max, required = false) {
  const result = String(value || "").trim();
  if (required && !result) throw new Error("Un champ obligatoire est manquant.");
  if (result.length > max) throw new Error("Un champ dépasse la longueur autorisée.");
  return result;
}

function normalizeCriteria(value) {
  if (!Array.isArray(value)) throw new Error("Les critères doivent être une liste.");
  if (value.length > 30) throw new Error("Une offre ne peut pas contenir plus de 30 critères.");
  const criteria = value.map((item) => ({
    label: cleanString(item.label, 300, true),
    required: Boolean(item.required)
  }));
  if (new Set(criteria.map((item) => item.label.toLocaleLowerCase("fr"))).size !== criteria.length) {
    throw new Error("Les critères doivent être distincts.");
  }
  return criteria;
}

function normalizeOptionalEmail(value, field) {
  if (value === undefined || value === null || value === "") return null;
  const email = cleanString(value, 254);
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error(`${field} invalide.`);
  return email;
}

function normalizeOptionalUrl(value) {
  if (value === undefined || value === null || value === "") return "";
  const url = cleanString(value, 500);
  try {
    const parsed = new URL(url);
    if (!new Set(["https:", "http:"]).has(parsed.protocol) || parsed.username || parsed.password) throw new Error();
    return parsed.toString();
  } catch {
    throw new Error("URL de portfolio invalide.");
  }
}

function normalizeOptionalDeadline(value) {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value)) {
    throw new Error("La date limite doit être une date ISO valide.");
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error("La date limite doit être une date ISO valide.");
  return date.toISOString();
}

function normalizeOptionalPositiveInteger(value, field) {
  if (value === undefined || value === null || value === "") return null;
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(`${field} invalide.`);
  return value;
}

function normalizeBoolean(value, field) {
  if (typeof value !== "boolean") throw new Error(`${field} doit être booléen.`);
  return value;
}

function assertAllowedStatusTransition(currentStatus, nextStatus) {
  if (currentStatus === nextStatus) return;
  const transitions = {
    draft: new Set(["published"]),
    published: new Set(["closed"]),
    closed: new Set(["archived"]),
    archived: new Set()
  };
  if (!transitions[currentStatus]?.has(nextStatus)) {
    throw new Error("La réouverture ou le retour d'une offre clôturée est interdit.");
  }
}

function validateJobPayload(body, { partial = false } = {}) {
  const output = {};
  const fields = ["title", "summary", "description", "location"];
  for (const field of fields) {
    if (!partial || body[field] !== undefined) {
      output[field] = cleanString(body[field], field === "description" ? 10000 : 300, true);
    }
  }
  if (!partial || body.slug !== undefined) {
    output.slug = cleanString(body.slug, 120, true);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(output.slug)) {
      throw new Error("Le slug doit contenir uniquement des minuscules, chiffres et tirets.");
    }
  }
  if (body.criteria !== undefined || !partial) output.criteria = normalizeCriteria(body.criteria);
  if (body.work_mode !== undefined || !partial) {
    output.work_mode = body.work_mode || "onsite";
    if (!["onsite", "hybrid", "remote"].includes(output.work_mode)) throw new Error("Mode de travail invalide.");
  }
  if (body.contract_type !== undefined || !partial) {
    output.contract_type = body.contract_type || "stage";
    if (!CONTRACT_TYPES.has(output.contract_type)) throw new Error("Type de contrat invalide.");
  }
  if (body.status !== undefined || !partial) {
    output.status = body.status || "draft";
    if (!JOB_STATUSES.has(output.status)) throw new Error("Statut d'offre invalide.");
  }
  if (body.employer_type !== undefined || !partial) {
    output.employer_type = body.employer_type || "techzone";
    if (!new Set(["techzone", "partner"]).has(output.employer_type)) {
      throw new Error("Type d'employeur invalide.");
    }
  }
  if (!partial && output.employer_type === "partner" && !body.partner_name) {
    throw new Error("Le nom du partenaire est requis.");
  }
  if (body.partner_name !== undefined || (!partial && output.employer_type === "partner")) {
    output.partner_name = body.partner_name ? cleanString(body.partner_name, 160, true) : null;
  }
  if (body.application_deadline !== undefined) output.application_deadline = normalizeOptionalDeadline(body.application_deadline);
  if (body.image_media_id !== undefined) output.image_media_id = normalizeOptionalPositiveInteger(body.image_media_id, "L'identifiant image");
  if (body.sender_display_name !== undefined) output.sender_display_name = body.sender_display_name ? cleanString(body.sender_display_name, 120) : null;
  if (body.signature_html !== undefined) output.signature_html = body.signature_html ? cleanString(body.signature_html, 10000) : null;
  if (body.reply_to !== undefined) output.reply_to = normalizeOptionalEmail(body.reply_to, "L'adresse de réponse");
  if (body.urgent !== undefined || !partial) output.urgent = normalizeBoolean(body.urgent ?? false, "Urgent");
  if (output.status === "published" && output.criteria && output.criteria.length === 0) {
    throw new Error("Une offre publiée doit contenir au moins un critère explicite.");
  }
  return output;
}

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function toPublicJob(job, resolveMediaAsset) {
  return {
    public_id: job.public_id,
    slug: job.slug,
    title: job.title,
    summary: job.summary,
    description: job.description,
    criteria: job.criteria,
    location: job.location,
    work_mode: job.work_mode,
    contract_type: job.contract_type,
    employer_type: job.employer_type,
    partner_name: job.partner_name,
    urgent: job.urgent,
    application_deadline: job.application_deadline,
    image: resolveMediaAsset?.(job.image_media_id) || null
  };
}

function decodeCursor(value) {
  if (!value || typeof value !== "string" || value.length > 300) return null;
  try {
    const decoded = JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
    if (typeof decoded.createdAt !== "string" || !Number.isSafeInteger(decoded.id) || decoded.id < 1) throw new Error();
    return decoded;
  } catch {
    throw new Error("Curseur de pagination invalide.");
  }
}

function encodeCursor(application) {
  return Buffer.from(JSON.stringify({ createdAt: application.created_at, id: application.id })).toString("base64url");
}

function parseApplicationListQuery(query) {
  const allowed = new Set(["limit", "cursor", "job_id", "processing_status", "hr_decision"]);
  for (const key of Object.keys(query)) {
    if (!allowed.has(key) || Array.isArray(query[key])) throw new Error("Paramètre de liste invalide.");
  }
  const limit = query.limit === undefined ? 25 : Number(query.limit);
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
    throw new Error("La limite doit être comprise entre 1 et 100.");
  }
  const jobId = query.job_id === undefined ? undefined : Number(query.job_id);
  if (jobId !== undefined && (!Number.isSafeInteger(jobId) || jobId < 1)) {
    throw new Error("Identifiant d'offre invalide.");
  }
  if (query.processing_status !== undefined && !PROCESSING_STATUSES.has(query.processing_status)) {
    throw new Error("Statut de traitement invalide.");
  }
  if (query.hr_decision !== undefined && !DECISIONS.has(query.hr_decision)) {
    throw new Error("Décision RH invalide.");
  }
  return {
    limit,
    jobId,
    processingStatus: query.processing_status,
    hrDecision: query.hr_decision,
    cursor: decodeCursor(query.cursor)
  };
}

function toApplicationListItem(application) {
  return {
    id: application.id,
    public_id: application.public_id,
    full_name: application.full_name,
    email: application.email,
    job_id: application.job_id,
    job_title: application.job_title,
    job_slug: application.job_slug,
    processing_status: application.processing_status,
    hr_decision: application.hr_decision,
    created_at: application.created_at
  };
}

function toApplicationDetail(application) {
  const { analysis_json, ...safeApplication } = application;
  return safeApplication;
}

function clientError(error) {
  if (error?.code === "SQLITE_CONSTRAINT_UNIQUE" && /recruitment_jobs\.slug/i.test(error.message)) {
    return "Ce slug est déjà utilisé.";
  }
  return error.message;
}

function formatSmtpFrom(configuredFrom, displayName) {
  const addressMatch = String(configuredFrom || "").match(/<([^>]+)>/) ||
    String(configuredFrom || "").match(/([^\s<>]+@[^\s<>]+)/);
  const address = addressMatch?.[1] || addressMatch?.[0];
  if (!address) throw new Error("SMTP_FROM ne contient pas d'adresse valide.");
  const safeName = String(displayName || "TECH ZONE Recrutement")
    .replace(/[\r\n<>]/g, " ")
    .trim()
    .slice(0, 120);
  return { name: safeName, address };
}

function createRouters({ repository, config, encryptionKey, aiService, transporter, resolveMediaAsset }) {
  const publicRouter = express.Router();
  const adminRouter = express.Router();
  const maxBytes = Number(config.maxFileMb || 10) * 1024 * 1024;
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: maxBytes, files: 2 }
  }).fields([{ name: "cv", maxCount: 1 }, { name: "cover_letter", maxCount: 1 }]);
  const applicationLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: Number(config.applicationRateLimit || 5),
    standardHeaders: true,
    legacyHeaders: false
  });

  publicRouter.get("/offres", (req, res) => {
    const jobs = repository.listJobs({ publicOnly: true }).map((job) =>
      toPublicJob(job, resolveMediaAsset)
    );
    res.json({ total: jobs.length, offres: jobs });
  });

  publicRouter.get("/offres/:slug", (req, res) => {
    const job = repository.getPublishedJobBySlug(req.params.slug);
    if (!job) return res.status(404).json({ error: "Offre introuvable." });
    res.json({ offre: toPublicJob(job, resolveMediaAsset) });
  });

  publicRouter.post(
    "/offres/:publicId/candidatures",
    applicationLimiter,
    upload,
    asyncRoute(async (req, res) => {
      const job = repository.getJobByPublicId(req.params.publicId);
      if (!job || job.status !== "published") return res.status(404).json({ error: "Offre introuvable." });
      if (job.application_deadline && new Date(job.application_deadline) < new Date()) {
        return res.status(410).json({ error: "Cette offre n'accepte plus de candidatures." });
      }
      const captchaValid = await verifyTurnstile({
        secret: config.turnstileSecret,
        token: req.body.turnstile_token,
        ip: req.ip,
        fetchImpl: config.fetchImpl,
        bypass: Boolean(config.bypassTurnstile)
      });
      if (!captchaValid) return res.status(400).json({ error: "Vérification anti-robot invalide." });
      if (![true, "true", "1", 1].includes(req.body.consent)) {
        return res.status(400).json({ error: "Votre consentement explicite est requis." });
      }
      const cv = req.files?.cv?.[0];
      const coverLetter = req.files?.cover_letter?.[0];
      if (!cv) return res.status(400).json({ error: "Le CV est requis." });
      const documents = [
        { kind: "cv", file: cv },
        ...(coverLetter ? [{ kind: "cover_letter", file: coverLetter }] : [])
      ];
      try {
        for (const document of documents) {
          document.mimeType = validateCandidateDocument(document.file, maxBytes);
        }
      } catch (error) {
        return res.status(400).json({ error: error.message });
      }
      let payload;
      try {
        payload = {
          full_name: cleanString(req.body.full_name, 160, true),
          email: cleanString(req.body.email, 254, true),
          phone: cleanString(req.body.phone, 50, true),
          candidate_location: cleanString(req.body.candidate_location, 160),
          portfolio_url: normalizeOptionalUrl(req.body.portfolio_url)
        };
      } catch (error) {
        return res.status(400).json({ error: error.message });
      }
      if (!/^\S+@\S+\.\S+$/.test(payload.email)) return res.status(400).json({ error: "Email invalide." });
      let application;
      const writtenPaths = [];
      try {
        application = repository.createApplication(job.id, payload);
        for (const document of documents) {
          const encrypted = encryptDocument({
            buffer: document.file.buffer,
            storageDir: config.storageDir,
            key: encryptionKey,
            applicationPublicId: application.public_id,
            kind: document.kind
          });
          writtenPaths.push(encrypted.encrypted_path);
          repository.addFile(application.id, {
            kind: document.kind,
            original_name: document.file.originalname,
            mime_type: document.mimeType,
            size_bytes: document.file.size,
            ...encrypted
          });
        }
      } catch (error) {
        for (const filename of writtenPaths) fs.rmSync(filename, { force: true });
        // Avoid leaving an incomplete dossier if encryption or metadata storage failed.
        if (application) repository.deleteApplication(application.id);
        if (/UNIQUE constraint failed/.test(error.message)) {
          return res.status(409).json({ error: "Une candidature existe déjà pour cet email et cette offre." });
        }
        throw error;
      }
      repository.recordEvent(application.id, "application_received", "candidate");
      res.status(202).json({ application_id: application.public_id, status: "queued" });
    })
  );

  adminRouter.get("/offres", (req, res) => res.json({ offres: repository.listJobs() }));
  adminRouter.post("/offres", (req, res) => {
    try {
      const payload = validateJobPayload(req.body);
      if (payload.status === "published" && payload.application_deadline && new Date(payload.application_deadline).getTime() <= Date.now()) {
        throw new Error("Une offre publiée doit avoir une date limite future.");
      }
      res.status(201).json({ offre: repository.createJob(payload) });
    } catch (error) {
      res.status(400).json({ error: clientError(error) });
    }
  });
  adminRouter.patch("/offres/:id", (req, res) => {
    try {
      const existing = repository.getJobById(req.params.id);
      if (!existing) return res.status(404).json({ error: "Offre introuvable." });
      const changes = validateJobPayload(req.body, { partial: true });
      const nextStatus = changes.status || existing.status;
      const nextCriteria = changes.criteria || existing.criteria;
      const nextEmployerType = changes.employer_type || existing.employer_type;
      const nextPartnerName = changes.partner_name ?? existing.partner_name;
      if (nextStatus === "published" && nextCriteria.length === 0) {
        return res.status(400).json({ error: "Une offre publiée doit contenir au moins un critère explicite." });
      }
      if (nextEmployerType === "partner" && !nextPartnerName) {
        return res.status(400).json({ error: "Le nom du partenaire est requis." });
      }
      assertAllowedStatusTransition(existing.status, nextStatus);
      const nextDeadline = changes.application_deadline ?? existing.application_deadline;
      if (nextStatus === "published" && nextDeadline && new Date(nextDeadline).getTime() <= Date.now()) {
        return res.status(400).json({ error: "Une offre publiée doit avoir une date limite future." });
      }
      const job = repository.updateJob(req.params.id, changes);
      if (!job) return res.status(404).json({ error: "Offre introuvable." });
      res.json({ offre: job });
    } catch (error) {
      res.status(400).json({ error: clientError(error) });
    }
  });
  adminRouter.delete("/offres/:id", (req, res) => {
    if (!repository.getJobById(req.params.id)) {
      return res.status(404).json({ error: "Offre introuvable." });
    }
    if (!repository.deleteJob(req.params.id)) {
      return res.status(409).json({ error: "Seul un brouillon sans candidature peut être supprimé." });
    }
    res.status(204).end();
  });

  adminRouter.get("/candidatures", (req, res) => {
    try {
      const query = parseApplicationListQuery(req.query);
      const applications = repository.listApplications(query);
      const hasNext = applications.length > query.limit;
      const candidatures = applications.slice(0, query.limit).map(toApplicationListItem);
      res.json({
        candidatures,
        pagination: {
          limit: query.limit,
          next_cursor: hasNext ? encodeCursor(applications[query.limit - 1]) : null
        }
      });
    } catch (error) {
      res.status(400).json({ error: clientError(error) });
    }
  });
  adminRouter.get("/candidatures/:id", (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    const files = repository.listFiles(application.id).map(({ encrypted_path, iv, auth_tag, ...file }) => file);
    res.json({ candidature: toApplicationDetail(application), fichiers: files });
  });
  adminRouter.get("/candidatures/:id/events", (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    res.json({ evenements: repository.listEvents(application.id) });
  });
  adminRouter.get("/candidatures/:id/fichiers/:fileId", (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    const file = repository.getFile(req.params.fileId);
    if (!application || !file || file.application_id !== application.id) {
      return res.status(404).json({ error: "Fichier introuvable." });
    }
    try {
      const buffer = decryptDocument(file, encryptionKey);
      res.setHeader("Content-Type", "application/octet-stream");
      res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(file.original_name)}`);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "private, no-store");
      res.send(buffer);
    } catch (error) {
      // Do not send filesystem or crypto details to the process logs.
      console.error(`Échec de déchiffrement pour le fichier ${file.id}.`);
      res.status(500).json({ error: "Impossible de déchiffrer ce document." });
    }
  });
  adminRouter.post("/candidatures/:id/retry-analysis", (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    if (!repository.retryAnalysis(application.id)) {
      return res.status(409).json({ error: "Seule une analyse échouée peut être relancée." });
    }
    repository.recordEvent(application.id, "analysis_retry_requested", req.adminUser?.email || "admin");
    res.status(202).json({ status: "queued" });
  });
  adminRouter.patch("/candidatures/:id/decision", (req, res) => {
    if (!DECISIONS.has(req.body.decision)) return res.status(400).json({ error: "Décision invalide." });
    const actor = req.adminUser?.email || "admin";
    const application = repository.setDecision(req.params.id, req.body.decision, actor);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    repository.recordEvent(application.id, "hr_decision_changed", actor, { decision: req.body.decision });
    res.json({ candidature: application });
  });
  adminRouter.post("/candidatures/:id/email-draft", asyncRoute(async (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    if (application.hr_decision !== "selected") {
      return res.status(409).json({ error: "Le candidat doit être marqué retenu avant de préparer cet email." });
    }
    const job = repository.getJobById(application.job_id);
    const draft = await aiService.draftSelectionEmail({ application, job });
    const signature = sanitizeEmailHtml(job.signature_html || "<p>L'équipe recrutement TECH ZONE</p>");
    res.json({
      draft: {
        subject: draft.subject,
        html: `${sanitizeEmailHtml(draft.html)}${signature}`,
        recipient: application.email,
        sender_display_name: job.sender_display_name || (job.employer_type === "partner" ? job.partner_name : "TECH ZONE Recrutement"),
        reply_to: job.reply_to || null
      }
    });
  }));
  adminRouter.post("/candidatures/:id/emails/send", asyncRoute(async (req, res) => {
    const application = repository.getApplicationById(req.params.id);
    if (!application) return res.status(404).json({ error: "Candidature introuvable." });
    if (application.hr_decision !== "selected" || req.body.confirmed !== true) {
      return res.status(409).json({ error: "Décision RH et confirmation explicite requises." });
    }
    const idempotencyKey = cleanString(req.body.idempotency_key, 200, true);
    const subject = cleanString(req.body.subject, 240, true);
    const html = sanitizeEmailHtml(req.body.html);
    if (!html) return res.status(400).json({ error: "Le contenu de l'email est vide." });
    const actor = req.adminUser?.email || "admin";
    let emailId;
    try {
      const result = repository.db.prepare(`
        INSERT INTO recruitment_emails (
          application_id, idempotency_key, recipient, subject, html_body,
          text_body, status, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, 'sending', ?)
      `).run(application.id, idempotencyKey, application.email, subject, html, htmlToText(html), actor);
      emailId = result.lastInsertRowid;
    } catch (error) {
      if (/UNIQUE constraint failed/.test(error.message)) {
        const existing = repository.db.prepare("SELECT * FROM recruitment_emails WHERE idempotency_key = ?").get(idempotencyKey);
        if (existing.status === "sent") {
          return res.status(200).json({ email: existing, duplicate: true });
        }
        if (existing.status === "sending") {
          return res.status(409).json({ email: existing, duplicate: true });
        }
        const claimed = repository.db.prepare(`
          UPDATE recruitment_emails SET status='sending', error_message=NULL
          WHERE id=? AND status='failed'
        `).run(existing.id).changes;
        if (!claimed) return res.status(409).json({ email: existing, duplicate: true });
        emailId = existing.id;
      } else {
        throw error;
      }
    }
    try {
      const job = repository.getJobById(application.job_id);
      const info = await transporter.sendMail({
        from: formatSmtpFrom(config.smtpFrom, job.sender_display_name || (job.employer_type === "partner" ? job.partner_name : null)),
        to: application.email,
        replyTo: job.reply_to || undefined,
        subject,
        html,
        text: htmlToText(html),
        headers: { "X-TechZone-Idempotency-Key": idempotencyKey }
      });
      repository.db.prepare(`
        UPDATE recruitment_emails SET status='sent', smtp_message_id=?, sent_at=datetime('now') WHERE id=?
      `).run(info.messageId || null, emailId);
      repository.recordEvent(application.id, "selection_email_sent", actor, { idempotency_key: idempotencyKey });
      res.json({ success: true, email_id: emailId });
    } catch (error) {
      repository.db.prepare("UPDATE recruitment_emails SET status='failed', error_message=? WHERE id=?")
        .run("Échec d'envoi SMTP.", emailId);
      repository.recordEvent(application.id, "selection_email_failed", actor, { email_id: Number(emailId) });
      throw error;
    }
  }));

  return { adminRouter, publicRouter };
}

module.exports = { createRouters, validateJobPayload };
