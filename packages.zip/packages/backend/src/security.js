const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const sanitizeHtml = require("sanitize-html");

const PDF_MIME = "application/pdf";
const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const SAFE_EMAIL_TAGS = ["p", "br", "strong", "em", "ul", "ol", "li", "a"];

function getEncryptionKey(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9+/]{43}=$/.test(value)) {
    throw new Error("RECRUITMENT_FILE_KEY must contain exactly 32 base64-encoded bytes.");
  }
  const key = Buffer.from(value, "base64");
  if (key.length !== 32) {
    throw new Error("RECRUITMENT_FILE_KEY must contain exactly 32 base64-encoded bytes.");
  }
  return key;
}

function validatePdf(buffer) {
  if (buffer.length < 5 || buffer.subarray(0, 5).toString("ascii") !== "%PDF-") {
    throw new Error("Le contenu ne correspond pas à un PDF valide.");
  }
  if (!buffer.subarray(Math.max(0, buffer.length - 4096)).includes(Buffer.from("%%EOF", "ascii"))) {
    throw new Error("Le PDF est incomplet ou corrompu.");
  }
  return PDF_MIME;
}

function readZipEntries(buffer) {
  const minimumEocdSize = 22;
  const searchStart = Math.max(0, buffer.length - minimumEocdSize - 0xffff);
  let eocdOffset = -1;
  for (let offset = buffer.length - minimumEocdSize; offset >= searchStart; offset -= 1) {
    if (
      buffer.readUInt32LE(offset) === 0x06054b50 &&
      offset + minimumEocdSize + buffer.readUInt16LE(offset + 20) === buffer.length
    ) {
      eocdOffset = offset;
      break;
    }
  }
  if (eocdOffset < 0) throw new Error("Le document DOCX est corrompu.");

  const entriesCount = buffer.readUInt16LE(eocdOffset + 10);
  const directorySize = buffer.readUInt32LE(eocdOffset + 12);
  const directoryOffset = buffer.readUInt32LE(eocdOffset + 16);
  if (
    buffer.readUInt16LE(eocdOffset + 4) !== 0 ||
    buffer.readUInt16LE(eocdOffset + 6) !== 0 ||
    buffer.readUInt16LE(eocdOffset + 8) !== entriesCount ||
    entriesCount === 0xffff ||
    directorySize === 0xffffffff ||
    directoryOffset === 0xffffffff ||
    entriesCount > 1000 ||
    directoryOffset + directorySize > eocdOffset
  ) {
    throw new Error("Le document DOCX est corrompu.");
  }

  const entries = [];
  let offset = directoryOffset;
  for (let index = 0; index < entriesCount; index += 1) {
    if (offset + 46 > directoryOffset + directorySize || buffer.readUInt32LE(offset) !== 0x02014b50) {
      throw new Error("Le document DOCX est corrompu.");
    }
    const flags = buffer.readUInt16LE(offset + 8);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const nextOffset = offset + 46 + nameLength + extraLength + commentLength;
    if (nextOffset > directoryOffset + directorySize || flags & 0x1) {
      throw new Error("Le document DOCX est corrompu.");
    }
    entries.push({
      name: buffer.subarray(offset + 46, offset + 46 + nameLength).toString(flags & 0x800 ? "utf8" : "latin1"),
      inflatedSize: buffer.readUInt32LE(offset + 24)
    });
    offset = nextOffset;
  }
  if (offset !== directoryOffset + directorySize) throw new Error("Le document DOCX est corrompu.");
  return entries;
}

function validateDocx(buffer, originalName) {
  if (!/\.docx$/i.test(originalName) || /\.docm$/i.test(originalName)) {
    throw new Error("Seuls les documents DOCX sans macro sont acceptés.");
  }
  const entries = readZipEntries(buffer);
  const names = new Set(entries.map((entry) => entry.name));
  const inflatedSize = entries.reduce((total, entry) => total + entry.inflatedSize, 0);
  if (!names.has("[Content_Types].xml") || !names.has("word/document.xml")) {
    throw new Error("Le fichier n'est pas un document DOCX valide.");
  }
  if (entries.some((entry) => /vbaProject\.bin$/i.test(entry.name))) {
    throw new Error("Les documents contenant des macros sont refusés.");
  }
  if (entries.some((entry) => entry.name.includes("..") || entry.name.startsWith("/") || entry.name.includes("\0"))) {
    throw new Error("Le document DOCX contient un chemin non sûr.");
  }
  if (inflatedSize > 30 * 1024 * 1024) {
    throw new Error("Le document DOCX décompressé est trop volumineux.");
  }
  return DOCX_MIME;
}

function validateCandidateDocument(file, maxBytes) {
  if (!file?.buffer?.length) throw new Error("Le fichier est vide.");
  if (file.buffer.length > maxBytes) throw new Error("Le fichier dépasse la taille autorisée.");
  const extension = path.extname(file.originalname || "").toLowerCase();
  if (extension === ".pdf") return validatePdf(file.buffer);
  if (extension === ".docx") return validateDocx(file.buffer, file.originalname);
  throw new Error("Format non supporté. Utilisez PDF ou DOCX.");
}

function encryptDocument({ buffer, storageDir, key, applicationPublicId, kind }) {
  fs.mkdirSync(storageDir, { recursive: true, mode: 0o700 });
  fs.chmodSync(storageDir, 0o700);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
  const authTag = cipher.getAuthTag();
  const filename = `${applicationPublicId}-${kind}-${crypto.randomUUID()}.enc`;
  const encryptedPath = path.join(storageDir, filename);
  fs.writeFileSync(encryptedPath, encrypted, { mode: 0o600, flag: "wx" });
  return {
    encrypted_path: encryptedPath,
    iv: iv.toString("base64"),
    auth_tag: authTag.toString("base64"),
    sha256: crypto.createHash("sha256").update(buffer).digest("hex")
  };
}

// Node fs/crypto errors embed the absolute server path in their message
// (e.g. "ENOENT: ... open '/var/lib/techzone/recruitment/<file>.enc'").
// This strips any such path so it never reaches a database column, an
// API response, or a server log.
function sanitizeStorageError(error) {
  const message = String(error?.message || "Erreur de traitement du document.");
  return message
    .replace(/open '[^']*'/gi, "open '[fichier]'")
    .replace(/'[^']*\.enc'/gi, "'[fichier]'");
}

function decryptDocument(file, key) {
  try {
    const encrypted = fs.readFileSync(file.encrypted_path);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(file.iv, "base64"));
    decipher.setAuthTag(Buffer.from(file.auth_tag, "base64"));
    return Buffer.concat([decipher.update(encrypted), decipher.final()]);
  } catch (error) {
    // Never let the raw error (with its absolute file path) escape this
    // function: routes and the worker only ever see the sanitized message.
    throw new Error(sanitizeStorageError(error));
  }
}

function sanitizeEmailHtml(value) {
  return sanitizeHtml(String(value || ""), {
    allowedTags: SAFE_EMAIL_TAGS,
    allowedAttributes: { a: ["href"] },
    allowedSchemes: ["https", "mailto"]
  });
}

function htmlToText(value) {
  return sanitizeHtml(value, { allowedTags: [], allowedAttributes: {} })
    .replace(/\s+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function verifyTurnstile({ secret, token, ip, fetchImpl = fetch, bypass = false }) {
  if (bypass) return true;
  if (!secret || !token) return false;
  const body = new URLSearchParams({ secret, response: token });
  if (ip) body.set("remoteip", ip);
  const response = await fetchImpl("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    body
  });
  const result = await response.json();
  return Boolean(result.success);
}

module.exports = {
  DOCX_MIME,
  PDF_MIME,
  decryptDocument,
  encryptDocument,
  getEncryptionKey,
  htmlToText,
  sanitizeEmailHtml,
  sanitizeStorageError,
  validateCandidateDocument,
  verifyTurnstile
};
