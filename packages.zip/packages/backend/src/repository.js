const { randomUUID } = require("node:crypto");

function parseJson(value, fallback) {
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function mapJob(row) {
  if (!row) return null;
  return {
    ...row,
    urgent: Boolean(row.urgent),
    criteria: parseJson(row.criteria_json, [])
  };
}

function mapApplication(row) {
  if (!row) return null;
  return {
    ...row,
    analysis: parseJson(row.analysis_json, null)
  };
}

function createRepository(db) {
  const insertJob = db.prepare(`
    INSERT INTO recruitment_jobs (
      public_id, slug, title, summary, description, criteria_json, location,
      work_mode, contract_type, employer_type, partner_name, status, urgent,
      application_deadline, image_media_id, sender_display_name, signature_html,
      reply_to, published_at, closed_at
    ) VALUES (
      @public_id, @slug, @title, @summary, @description, @criteria_json, @location,
      @work_mode, @contract_type, @employer_type, @partner_name, @status, @urgent,
      @application_deadline, @image_media_id, @sender_display_name, @signature_html,
      @reply_to, @published_at, @closed_at
    )
  `);

  function normalizeJob(input, existing = {}) {
    const status = input.status ?? existing.status ?? "draft";
    return {
      public_id: existing.public_id || randomUUID(),
      slug: input.slug ?? existing.slug,
      title: input.title ?? existing.title,
      summary: input.summary ?? existing.summary,
      description: input.description ?? existing.description,
      criteria_json: JSON.stringify(input.criteria ?? existing.criteria ?? []),
      location: input.location ?? existing.location,
      work_mode: input.work_mode ?? existing.work_mode ?? "onsite",
      contract_type: input.contract_type ?? existing.contract_type ?? "stage",
      employer_type: input.employer_type ?? existing.employer_type ?? "techzone",
      partner_name: input.partner_name ?? existing.partner_name ?? null,
      status,
      urgent: input.urgent === undefined ? Number(existing.urgent || 0) : Number(Boolean(input.urgent)),
      application_deadline: input.application_deadline ?? existing.application_deadline ?? null,
      image_media_id: input.image_media_id ?? existing.image_media_id ?? null,
      sender_display_name: input.sender_display_name ?? existing.sender_display_name ?? null,
      signature_html: input.signature_html ?? existing.signature_html ?? null,
      reply_to: input.reply_to ?? existing.reply_to ?? null,
      published_at:
        status === "published" ? existing.published_at || new Date().toISOString() : existing.published_at || null,
      closed_at:
        status === "closed" ? existing.closed_at || new Date().toISOString() : existing.closed_at || null
    };
  }

  function createJob(input) {
    const data = normalizeJob(input);
    const result = insertJob.run(data);
    return getJobById(result.lastInsertRowid);
  }

  function updateJob(id, input) {
    const existing = getJobById(id);
    if (!existing) return null;
    const data = { id: Number(id), ...normalizeJob(input, existing) };
    db.prepare(`
      UPDATE recruitment_jobs SET
        slug=@slug, title=@title, summary=@summary, description=@description,
        criteria_json=@criteria_json, location=@location, work_mode=@work_mode,
        contract_type=@contract_type, employer_type=@employer_type,
        partner_name=@partner_name, status=@status, urgent=@urgent,
        application_deadline=@application_deadline, image_media_id=@image_media_id,
        sender_display_name=@sender_display_name, signature_html=@signature_html,
        reply_to=@reply_to, published_at=@published_at, closed_at=@closed_at,
        updated_at=datetime('now')
      WHERE id=@id
    `).run(data);
    return getJobById(id);
  }

  function getJobById(id) {
    return mapJob(db.prepare("SELECT * FROM recruitment_jobs WHERE id = ?").get(Number(id)));
  }

  function getJobByPublicId(publicId) {
    return mapJob(db.prepare("SELECT * FROM recruitment_jobs WHERE public_id = ?").get(publicId));
  }

  function getPublishedJobBySlug(slug) {
    return mapJob(db.prepare(`
      SELECT * FROM recruitment_jobs
      WHERE slug = ? AND status = 'published'
        AND (application_deadline IS NULL OR julianday(application_deadline) >= julianday('now'))
    `).get(slug));
  }

  function listJobs({ publicOnly = false } = {}) {
    const where = publicOnly
      ? "WHERE status='published' AND (application_deadline IS NULL OR julianday(application_deadline) >= julianday('now'))"
      : "";
    return db.prepare(`SELECT * FROM recruitment_jobs ${where} ORDER BY urgent DESC, created_at DESC`).all().map(mapJob);
  }

  function deleteJob(id) {
    return db.prepare(`
      DELETE FROM recruitment_jobs
      WHERE id = ? AND status = 'draft'
        AND NOT EXISTS (
          SELECT 1 FROM recruitment_applications WHERE job_id = recruitment_jobs.id
        )
    `).run(Number(id)).changes > 0;
  }

  function deleteApplication(id) {
    return db.prepare("DELETE FROM recruitment_applications WHERE id = ?").run(Number(id)).changes > 0;
  }

  function createApplication(jobId, input) {
    const publicId = randomUUID();
    const result = db.prepare(`
      INSERT INTO recruitment_applications (
        public_id, job_id, full_name, email, normalized_email, phone,
        candidate_location, portfolio_url, consent_at, processing_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued')
    `).run(
      publicId,
      Number(jobId),
      input.full_name,
      input.email,
      input.email.trim().toLowerCase(),
      input.phone,
      input.candidate_location || null,
      input.portfolio_url || null,
      new Date().toISOString()
    );
    return getApplicationById(result.lastInsertRowid);
  }

  function getApplicationById(id) {
    return mapApplication(db.prepare(`
      SELECT a.*, j.title AS job_title, j.slug AS job_slug,
             j.criteria_json AS job_criteria_json, j.employer_type,
             j.partner_name, j.sender_display_name, j.signature_html, j.reply_to
      FROM recruitment_applications a
      JOIN recruitment_jobs j ON j.id = a.job_id
      WHERE a.id = ?
    `).get(Number(id)));
  }

  function listApplications({ jobId, processingStatus, hrDecision, cursor, limit = 25 } = {}) {
    const conditions = [];
    const params = [];
    if (jobId) {
      conditions.push("a.job_id = ?");
      params.push(jobId);
    }
    if (processingStatus) {
      conditions.push("a.processing_status = ?");
      params.push(processingStatus);
    }
    if (hrDecision) {
      conditions.push("a.hr_decision = ?");
      params.push(hrDecision);
    }
    if (cursor) {
      conditions.push("(a.created_at < ? OR (a.created_at = ? AND a.id < ?))");
      params.push(cursor.createdAt, cursor.createdAt, cursor.id);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    return db.prepare(`
      SELECT a.*, j.title AS job_title, j.slug AS job_slug
      FROM recruitment_applications a
      JOIN recruitment_jobs j ON j.id = a.job_id
      ${where}
      ORDER BY a.created_at DESC, a.id DESC
      LIMIT ?
    `).all(...params, limit + 1).map(mapApplication);
  }

  function addFile(applicationId, file) {
    const result = db.prepare(`
      INSERT INTO recruitment_files (
        application_id, kind, original_name, mime_type, size_bytes, sha256,
        encrypted_path, iv, auth_tag
      ) VALUES (@application_id, @kind, @original_name, @mime_type, @size_bytes,
                @sha256, @encrypted_path, @iv, @auth_tag)
    `).run({ application_id: Number(applicationId), ...file });
    return db.prepare("SELECT * FROM recruitment_files WHERE id = ?").get(result.lastInsertRowid);
  }

  function listFiles(applicationId) {
    return db.prepare("SELECT * FROM recruitment_files WHERE application_id =? ORDER BY kind").all(Number(applicationId));
  }

  function getFile(id) {
    return db.prepare("SELECT * FROM recruitment_files WHERE id = ?").get(Number(id));
  }

  function claimNextAnalysis() {
    const row = db.prepare(`
      UPDATE recruitment_applications
      SET processing_status='processing', processing_started_at=datetime('now'),
          analysis_attempts=analysis_attempts+1, analysis_error=NULL, updated_at=datetime('now')
      WHERE id = (
        SELECT id FROM recruitment_applications
        WHERE analysis_attempts < 3 AND (
          processing_status = 'queued' OR
          (processing_status = 'processing' AND processing_started_at < datetime('now', '-10 minutes'))
        )
        ORDER BY created_at ASC, id ASC LIMIT 1
      )
      AND analysis_attempts < 3 AND (
        processing_status = 'queued' OR
        (processing_status = 'processing' AND processing_started_at < datetime('now', '-10 minutes'))
      )
      RETURNING id
    `).get();
    if (!row) return null;
    return getApplicationById(row.id);
  }

  function completeAnalysis(id, analysis, model) {
    db.prepare(`
      UPDATE recruitment_applications
      SET processing_status='analysis_ready', analysis_json=?, analysis_model=?,
          analyzed_at=datetime('now'), analysis_error=NULL, updated_at=datetime('now')
      WHERE id=?
    `).run(JSON.stringify(analysis), model, Number(id));
  }

  function failAnalysis(id, error, retryable) {
    const current = getApplicationById(id);
    const status = retryable && current.analysis_attempts < 3 ? "queued" : "analysis_failed";
    db.prepare(`
      UPDATE recruitment_applications
      SET processing_status=?, analysis_error=?, updated_at=datetime('now') WHERE id=?
    `).run(status, String(error).slice(0, 1000), Number(id));
  }

  function retryAnalysis(id) {
    return db.prepare(`
      UPDATE recruitment_applications SET processing_status='queued',
        analysis_attempts=0, analysis_error=NULL, updated_at=datetime('now')
      WHERE id=? AND processing_status = 'analysis_failed'
    `).run(Number(id)).changes > 0;
  }

  function setDecision(id, decision, actor) {
    const changed = db.prepare(`
      UPDATE recruitment_applications SET hr_decision=?, decided_at=datetime('now'),
        decided_by=?, updated_at=datetime('now') WHERE id=?
    `).run(decision, actor, Number(id)).changes;
    return changed ? getApplicationById(id) : null;
  }

  function recordEvent(applicationId, eventType, actor, details = null) {
    db.prepare(`
      INSERT INTO recruitment_events(application_id, event_type, actor, details_json)
      VALUES (?, ?, ?, ?)
    `).run(applicationId || null, eventType, actor, details ? JSON.stringify(details) : null);
  }

  function listEvents(applicationId) {
    return db.prepare(`
      SELECT id, event_type, actor, details_json, created_at
      FROM recruitment_events
      WHERE application_id = ?
      ORDER BY created_at ASC
    `).all(Number(applicationId)).map((row) => ({
      id: row.id,
      event_type: row.event_type,
      actor: row.actor,
      created_at: row.created_at,
      details: parseJson(row.details_json, null)
    }));
  }

  return {
    db,
    addFile,
    claimNextAnalysis,
    completeAnalysis,
    createApplication,
    createJob,
    deleteApplication,
    deleteJob,
    failAnalysis,
    getApplicationById,
    getFile,
    getJobById,
    getJobByPublicId,
    getPublishedJobBySlug,
    listApplications,
    listEvents,
    listFiles,
    listJobs,
    recordEvent,
    retryAnalysis,
    setDecision,
    updateJob
  };
}

module.exports = { createRepository, mapApplication, mapJob };
