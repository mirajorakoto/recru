import { useEffect, useMemo, useRef, useState } from "react";
import DOMPurify from "dompurify";
import "./styles.css";

async function apiRequest(apiBaseUrl, path, options = {}) {
  const response = await fetch(`${apiBaseUrl}${path}`, {
    credentials: "include",
    headers: options.body ? { "Content-Type": "application/json", ...(options.headers || {}) } : options.headers,
    ...options
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || `HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

const emptyJob = {
  slug: "", title: "", summary: "", description: "", location: "Fianarantsoa",
  work_mode: "onsite", contract_type: "stage", employer_type: "techzone",
  partner_name: "", status: "draft", urgent: false, criteria: [],
  application_deadline: "", image_media_id: "", sender_display_name: "",
  reply_to: "", signature_html: ""
};

function JobEditor({ apiBaseUrl, job, onSaved, onCancel }) {
  const [draft, setDraft] = useState(job || emptyJob);
  const [criterion, setCriterion] = useState("");
  const [error, setError] = useState("");
  function set(name, value) { setDraft((current) => ({ ...current, [name]: value })); }
  async function submit(event) {
    event.preventDefault();
    try {
      await apiRequest(apiBaseUrl, job ? `/offres/${job.id}` : "/offres", {
        method: job ? "PATCH" : "POST",
        body: JSON.stringify(draft)
      });
      onSaved();
    } catch (caught) { setError(caught.message); }
  }
  return <form className="rh-editor" onSubmit={submit}>
    <div className="rh-editor-heading"><div><p className="rh-eyebrow">Publication</p><h2>{job ? "Modifier l'offre" : "Nouvelle offre"}</h2></div><button onClick={onCancel} type="button">Fermer</button></div>
    <div className="rh-form-grid">
      <label>Titre<input required value={draft.title} onChange={(event) => set("title", event.target.value)} /></label>
      <label>Slug<input required value={draft.slug} onChange={(event) => set("slug", event.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-"))} /></label>
      <label>Contrat<select value={draft.contract_type} onChange={(event) => set("contract_type", event.target.value)}>{["stage","cdd","cdi","alternance","freelance","interim","autre"].map((value) => <option key={value}>{value}</option>)}</select></label>
      <label>Mode<select value={draft.work_mode} onChange={(event) => set("work_mode", event.target.value)}><option value="onsite">Sur site</option><option value="hybrid">Hybride</option><option value="remote">À distance</option></select></label>
      <label>Employeur<select value={draft.employer_type} onChange={(event) => set("employer_type", event.target.value)}><option value="techzone">TechZone</option><option value="partner">Partenaire</option></select></label>
      {draft.employer_type === "partner" ? <label>Partenaire<input required value={draft.partner_name || ""} onChange={(event) => set("partner_name", event.target.value)} /></label> : null}
      <label>Lieu<input required value={draft.location} onChange={(event) => set("location", event.target.value)} /></label>
      <label>Statut<select value={draft.status} onChange={(event) => set("status", event.target.value)}><option value="draft">Brouillon</option><option value="published">Publié</option><option value="closed">Clôturé</option><option value="archived">Archivé</option></select></label>
      <label>Date limite<input type="datetime-local" value={(draft.application_deadline || "").slice(0, 16)} onChange={(event) => set("application_deadline", event.target.value || null)} /></label>
      <label>Identifiant image médiathèque<input min="1" type="number" value={draft.image_media_id || ""} onChange={(event) => set("image_media_id", event.target.value ? Number(event.target.value) : null)} /></label>
      <label>Nom affiché dans l'email<input maxLength="120" value={draft.sender_display_name || ""} onChange={(event) => set("sender_display_name", event.target.value)} /></label>
      <label>Adresse de réponse<input type="email" value={draft.reply_to || ""} onChange={(event) => set("reply_to", event.target.value)} /></label>
    </div>
    <label>Résumé<textarea required value={draft.summary} onChange={(event) => set("summary", event.target.value)} /></label>
    <label>Description<textarea required rows="7" value={draft.description} onChange={(event) => set("description", event.target.value)} /></label>
    <label>Signature email autorisée<textarea rows="3" value={draft.signature_html || ""} onChange={(event) => set("signature_html", event.target.value)} /></label>
    <fieldset><legend>Critères objectifs</legend><div className="rh-inline"><input placeholder="Ajouter un critère" value={criterion} onChange={(event) => setCriterion(event.target.value)} /><button onClick={() => { if (criterion.trim()) { set("criteria", [...draft.criteria, { label: criterion.trim(), required: true }]); setCriterion(""); } }} type="button">Ajouter</button></div><ul>{draft.criteria.map((item, index) => <li key={`${item.label}-${index}`}><label><input checked={item.required} onChange={(event) => set("criteria", draft.criteria.map((entry, entryIndex) => entryIndex === index ? { ...entry, required: event.target.checked } : entry))} type="checkbox" />Requis</label><span>{item.label}</span><button onClick={() => set("criteria", draft.criteria.filter((_, entryIndex) => entryIndex !== index))} type="button">Retirer</button></li>)}</ul></fieldset>
    <label className="rh-checkbox"><input checked={draft.urgent} onChange={(event) => set("urgent", event.target.checked)} type="checkbox" />Offre urgente</label>
    {error ? <p className="rh-error" role="alert">{error}</p> : null}<button className="rh-primary" type="submit">Enregistrer</button>
  </form>;
}

const STATUS_LABELS = { draft: "Brouillon", published: "Active", closed: "En pause", archived: "Archivée" };

function JobPreview({ job }) {
  return <aside className="rh-detail rh-detail-inline"><div className="rh-heading"><div><h3>{job.title}</h3><p className="rh-eyebrow">TechZone Recrutement</p></div><a className="rh-text-action" href={`/offres/${job.slug}`} target="_blank" rel="noreferrer">Voir l'offre ↗</a></div>
    <div className="rh-statuses"><span>{STATUS_LABELS[job.status] || job.status}</span><span>Publiée le {job.published_at ? humanDate(new Date(job.published_at)) : "—"}</span></div>
    <div className="rh-tabs" role="tablist"><button className="is-active" role="tab" type="button">Aperçu</button><button role="tab" type="button">Candidatures {typeof job.applications_count === "number" ? `(${job.applications_count})` : ""}</button><button role="tab" type="button">Paramètres</button></div>
    <h3>Description</h3><p>{job.summary}</p>
    <h3>Compétences et critères</h3><ul>{(job.criteria || []).map((item, index) => <li key={index}>✓ {item.label}</li>)}{(job.criteria || []).length === 0 ? <li>Aucun critère renseigné.</li> : null}</ul>
    <div className="rh-panel-grid-2"><div className="rh-panel"><h3>Étapes du processus</h3><ol className="rh-mini-steps"><li>Nouveau</li><li>À examiner</li><li>Entretien</li><li>En attente</li><li>Offre</li></ol></div><div className="rh-panel"><h3>Responsable</h3><p>Admin RH<br /><small>Équipe RH</small></p></div></div>
  </aside>;
}

function Offers({ apiBaseUrl, offers, refresh }) {
  const [editing, setEditing] = useState(undefined);
  const [previewed, setPreviewed] = useState(null);
  const active = offers.filter((job) => job.status === "published").length;
  const paused = offers.filter((job) => job.status === "closed").length;
  const drafts = offers.filter((job) => job.status === "draft").length;
  const totalApplications = offers.reduce((sum, job) => sum + (job.applications_count || 0), 0);
  return <section><div className="rh-heading"><div><p className="rh-eyebrow">Offres</p><h2>{offers.length} offre{offers.length > 1 ? "s" : ""} · Gérez et suivez vos offres d'emploi chez TechZone Recrutement.</h2></div><button className="rh-primary" onClick={() => setEditing(null)} type="button">Nouvelle offre</button></div>
    <div className="rh-metrics" aria-label="Indicateurs des offres">
      <div className="rh-metric"><span className="rh-icon-disc is-mint" aria-hidden="true">▤</span><span className="rh-metric-copy"><span>Offres actives</span><strong>{active}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-blue" aria-hidden="true">◷</span><span className="rh-metric-copy"><span>En pause</span><strong>{paused}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-amber" aria-hidden="true">✎</span><span className="rh-metric-copy"><span>Brouillons</span><strong>{drafts}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-mint" aria-hidden="true">♧</span><span className="rh-metric-copy"><span>Total des candidatures</span><strong>{totalApplications}</strong></span></div>
    </div>
    {editing !== undefined ? <JobEditor apiBaseUrl={apiBaseUrl} job={editing} onCancel={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); refresh(); }} /> : <div className="rh-split">
      <div className="rh-table-wrap"><table><thead><tr><th>Offre</th><th>Statut</th><th>Candidatures</th><th>Publiée le</th><th>Responsable</th><th></th></tr></thead><tbody>{offers.map((job) => <tr className={previewed?.id === job.id ? "is-selected" : ""} key={job.id} onClick={() => setPreviewed(job)}><td><strong>{job.title}</strong><small>TechZone Recrutement</small></td><td><i className={`rh-stage is-status-${job.status}`}>{STATUS_LABELS[job.status] || job.status}</i></td><td>{job.applications_count ?? "—"}</td><td>{job.published_at ? humanDate(new Date(job.published_at)) : "—"}</td><td>Admin RH</td><td><button onClick={(event) => { event.stopPropagation(); setEditing(job); }} type="button">Modifier</button></td></tr>)}</tbody></table>{offers.length === 0 ? <p className="rh-empty">Aucune offre pour le moment.</p> : null}</div>
      {previewed ? <JobPreview job={previewed} /> : null}
    </div>}
  </section>;
}

function RichEditor({ value, onChange }) {
  const ref = useRef(null);
  useEffect(() => { if (ref.current && ref.current.innerHTML !== value) ref.current.innerHTML = value; }, [value]);
  function command(name) { document.execCommand(name); onChange(ref.current.innerHTML); }
  return <div className="rh-rich"><div className="rh-toolbar" aria-label="Mise en forme"><button onClick={() => command("bold")} type="button"><strong>G</strong></button><button onClick={() => command("italic")} type="button"><em>I</em></button><button onClick={() => command("insertUnorderedList")} type="button">• Liste</button><button onClick={() => command("insertOrderedList")} type="button">1. Liste</button></div><div className="rh-contenteditable" contentEditable onInput={(event) => onChange(event.currentTarget.innerHTML)} ref={ref} role="textbox" tabIndex="0" /></div>;
}

const EVENT_LABELS = {
  application_received: "Dépôt de candidature",
  hr_decision_changed: "Décision RH modifiée",
  analysis_completed: "Analyse IA terminée",
  analysis_failed: "Échec de l'analyse IA",
  analysis_retry_requested: "Relance de l'analyse demandée",
  selection_email_failed: "Échec d'envoi de l'email",
  selection_email_sent: "Email de sélection envoyé",
  hr_note_added: "Note ajoutée",
  hr_viewed: "Consultation RH"
};

const EVENT_ICONS = {
  application_received: "▤", hr_decision_changed: "✓", analysis_completed: "✦",
  analysis_failed: "⚠", analysis_retry_requested: "↻", selection_email_failed: "⚠",
  selection_email_sent: "✉", hr_note_added: "✎", hr_viewed: "◉"
};

const DECISION_LABELS = { selected: "retenu", rejected: "rejeté", withdrawn: "retiré", to_review: "à revoir" };

function formatEventDetail(event) {
  if (event.event_type === "hr_decision_changed" && event.details?.decision) {
    return `Nouvelle décision : ${DECISION_LABELS[event.details.decision] || event.details.decision}`;
  }
  if (event.event_type === "analysis_completed" && event.details?.model) {
    return `Modèle : ${event.details.model}`;
  }
  if (event.event_type === "analysis_failed" && event.details?.message) {
    return event.details.message;
  }
  if (event.details?.note) return event.details.note;
  return null;
}

function relativeDay(value) {
  const days = Math.floor((Date.now() - new Date(value).getTime()) / 86400000);
  if (days <= 0) return "Aujourd'hui";
  if (days === 1) return "Hier";
  if (days < 7) return `Il y a ${days} j`;
  return `Il y a ${Math.floor(days / 7)} sem.`;
}

function EventHistory({ apiBaseUrl, candidateId, version }) {
  const [events, setEvents] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    apiRequest(apiBaseUrl, `/candidatures/${candidateId}/events`)
      .then((data) => setEvents(data.evenements))
      .catch((caught) => setError(caught.message));
  }, [apiBaseUrl, candidateId, version]);
  if (error) return <p className="rh-error" role="alert">{error}</p>;
  if (!events) return <p>Chargement…</p>;
  if (events.length === 0) return <p>Aucun événement enregistré.</p>;
  return <ol className="rh-timeline">{events.map((event) => <li key={event.id}>
    <span className="rh-timeline-icon" aria-hidden="true">{EVENT_ICONS[event.event_type] || "●"}</span>
    <div className="rh-timeline-copy">
      <div className="rh-timeline-row"><strong>{EVENT_LABELS[event.event_type] || event.event_type}</strong><small>{relativeDay(event.created_at)}</small></div>
      <p>{formatEventDetail(event) || `Événement enregistré par ${event.actor}.`}</p>
    </div>
  </li>)}</ol>;
}

function inferConfidence(item) {
  // Heuristique d'affichage : l'API ne renvoie pas encore de niveau de confiance
  // explicite par critère, seulement `assessment` (texte) et `evidence` (preuve).
  // À remplacer par un vrai champ `confidence` côté backend si disponible.
  if (!item.evidence) return { label: "À confirmer", tone: "amber" };
  return item.evidence.length > 80 ? { label: "Élevé", tone: "mint" } : { label: "Moyen", tone: "blue" };
}

function CandidateProfileTab({ apiBaseUrl, candidate, files }) {
  return <>
    <h3>Documents privés</h3>
    <div className="rh-inline">{files.map((file) => <a className="rh-doc-link" key={file.id} href={`${apiBaseUrl}/candidatures/${candidate.id}/fichiers/${file.id}`}>{file.kind === "cv" ? "Télécharger le CV" : "Télécharger la LM"}</a>)}</div>
    <h3>Coordonnées</h3>
    <ul className="rh-kv"><li><strong>Email</strong><span>{candidate.email}</span></li><li><strong>Téléphone</strong><span>{candidate.phone || "—"}</span></li><li><strong>Candidature reçue</strong><span>{humanDate(new Date(candidate.created_at))}</span></li></ul>
    {candidate.profile?.timeline ? <><h3>Chronologie professionnelle</h3><ol className="rh-timeline">{candidate.profile.timeline.map((entry, index) => <li key={index}><span className="rh-timeline-icon" aria-hidden="true">●</span><div className="rh-timeline-copy"><strong>{entry.title}</strong><small>{entry.org} · {entry.period}</small><p>{entry.description}</p></div></li>)}</ol></> : null}
    {candidate.profile?.declared_skills?.length ? <><h3>Compétences déclarées</h3><div className="rh-pills">{candidate.profile.declared_skills.map((skill) => <span key={skill}>{skill}</span>)}</div></> : null}
    <h3>Notes RH</h3>
    {candidate.notes?.length ? <ul>{candidate.notes.map((note, index) => <li key={index}>{note}</li>)}</ul> : <p className="rh-empty">Aucune note pour le moment — ajoutez-en une depuis l'onglet Activité.</p>}
  </>;
}

function CandidateAnalysisTab({ candidate, onRetry, pending }) {
  if (!candidate.analysis) return <>
    <p className="rh-empty">{candidate.analysis_error || "Analyse en attente."}</p>
    {candidate.processing_status === "analysis_failed" ? <button disabled={pending} onClick={onRetry} type="button">{pending ? "Relance…" : "Relancer l'analyse"}</button> : null}
  </>;
  return <>
    <div className="rh-info-box"><p><strong>Synthèse générée</strong>{candidate.analysis.generated_at ? ` le ${humanDate(new Date(candidate.analysis.generated_at))}` : ""} · À vérifier par un RH</p><p>{candidate.analysis.summary}</p></div>
    <div className="rh-table-wrap"><table><thead><tr><th>Critère</th><th>Éléments relevés dans le dossier</th><th>Niveau de confiance</th></tr></thead><tbody>{candidate.analysis.criteria.map((item) => { const confidence = inferConfidence(item); return <tr key={item.criterion}><td><strong>{item.criterion}</strong></td><td>{item.assessment}{item.evidence ? <small>{item.evidence}</small> : null}</td><td><span className={`rh-badge is-${confidence.tone}`}>{confidence.label}</span></td></tr>; })}</tbody></table></div>
    {candidate.analysis.clarifications?.length ? <div className="rh-warning"><div><strong>Informations à clarifier</strong><ul>{candidate.analysis.clarifications.map((point, index) => <li key={index}>{point}</li>)}</ul></div></div> : null}
    <p className="rh-note">L'IA analyse les éléments fournis ; elle ne remplace pas l'évaluation humaine.</p>
  </>;
}

function CandidateActivityTab({ apiBaseUrl, candidate, action, onDecide, onSendDraft, draft, setDraft, eventsVersion, onQuickNote, onQuickInterview }) {
  const [noteText, setNoteText] = useState("");
  return <>
    <EventHistory apiBaseUrl={apiBaseUrl} candidateId={candidate.id} version={eventsVersion} />
    <h3>Décision RH</h3>
    <div className="rh-actions"><button disabled={Boolean(action)} onClick={() => onDecide("to_review")} type="button">À revoir</button><button disabled={Boolean(action)} onClick={() => onDecide("selected")} type="button">Marquer retenu</button><button disabled={Boolean(action)} onClick={() => onDecide("rejected")} type="button">Marquer rejeté</button><button disabled={Boolean(action)} onClick={() => onDecide("withdrawn")} type="button">Retiré</button></div>
    {draft ? <div className="rh-email"><h3>Email proposé par IA</h3><label>Destinataire<input readOnly value={draft.recipient} /></label><label>Objet<input value={draft.subject} onChange={(event) => setDraft({ ...draft, subject: event.target.value })} /></label><RichEditor value={draft.html} onChange={(html) => setDraft({ ...draft, html })} /><div className="rh-preview" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(draft.html) }} /><button className="rh-primary" disabled={Boolean(action)} onClick={() => window.confirm("Confirmer l'envoi définitif de cet email ?") && onSendDraft()} type="button">{action === "email" ? "Envoi…" : "Confirmer et envoyer"}</button></div> : null}
    <div className="rh-inline rh-note-form"><input onChange={(event) => setNoteText(event.target.value)} placeholder="Ajouter une note…" value={noteText} /><button disabled={!noteText.trim()} onClick={() => { onQuickNote(noteText.trim()); setNoteText(""); }} type="button">Ajouter une note</button></div>
    <div className="rh-actions"><button onClick={onQuickInterview} type="button">Planifier un entretien</button><button className="rh-primary" disabled={Boolean(action)} onClick={() => onDecide("to_review")} type="button">Marquer comme examiné</button></div>
  </>;
}

function CandidateDetail({ apiBaseUrl, candidateId, onClose, refresh }) {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("profil");
  const [draft, setDraft] = useState(null);
  const [draftKey, setDraftKey] = useState(null);
  const [notice, setNotice] = useState("");
  const [action, setAction] = useState("");
  const [eventsVersion, setEventsVersion] = useState(0);
  useEffect(() => { setTab("profil"); setData(null); apiRequest(apiBaseUrl, `/candidatures/${candidateId}`).then(setData).catch((error) => setNotice(error.message)); }, [apiBaseUrl, candidateId]);
  if (!data) return <aside className="rh-detail"><button aria-label="Fermer le dossier" onClick={onClose} type="button"><span aria-hidden="true">←</span> Fermer</button><p>{notice || "Chargement…"}</p></aside>;
  const candidate = data.candidature;
  async function createDraft() {
    const result = await apiRequest(apiBaseUrl, `/candidatures/${candidate.id}/email-draft`, { method: "POST", body: "{}" });
    setDraft(result.draft);
    setDraftKey(window.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`);
  }
  async function decide(decision) {
    // B-045: a decision change must be confirmed, not applied on the first click —
    // this mirrors the confirmation already required before sending the email.
    const label = DECISION_LABELS[decision] || decision;
    if (!window.confirm(`Confirmer le changement de décision vers « ${label} » ?`)) return;
    setAction("decision");
    try {
      await apiRequest(apiBaseUrl, `/candidatures/${candidate.id}/decision`, { method: "PATCH", body: JSON.stringify({ decision }) });
      setNotice("Décision enregistrée.");
      refresh();
      setEventsVersion((current) => current + 1);
      setDraft(null);
      if (decision === "selected") await createDraft();
    } catch (error) {
      setNotice(error.message);
    } finally {
      setAction("");
    }
  }
  async function retryAnalysis() {
    if (!window.confirm("Relancer l'analyse IA de ce dossier ?")) return;
    setAction("retry");
    try {
      await apiRequest(apiBaseUrl, `/candidatures/${candidate.id}/retry-analysis`, { method: "POST", body: "{}" });
      setNotice("Analyse remise en file d'attente.");
      refresh();
      setEventsVersion((current) => current + 1);
    } catch (error) {
      setNotice(error.message);
    } finally {
      setAction("");
    }
  }
  async function sendEmail() {
    setAction("email");
    try {
      await apiRequest(apiBaseUrl, `/candidatures/${candidate.id}/emails/send`, { method: "POST", body: JSON.stringify({ confirmed: true, idempotency_key: draftKey, subject: draft.subject, html: draft.html }) });
      setNotice("Email envoyé.");
      setEventsVersion((current) => current + 1);
    } catch (error) {
      setNotice(error.message);
    } finally {
      setAction("");
    }
  }
  function quickNote(text) {
    // Ajout optimiste, non persisté : aucune route backend de notes libres n'existe
    // pour l'instant (ex: POST /candidatures/:id/notes). À brancher le jour venu.
    setData((current) => ({ ...current, candidature: { ...current.candidature, notes: [...(current.candidature.notes || []), text] } }));
    setNotice("Note ajoutée localement (à synchroniser avec le serveur une fois l'endpoint disponible).");
  }
  function quickInterview() {
    // Même remarque : pas de route de planification d'entretien connue à ce jour.
    const when = window.prompt("Proposer une date d'entretien (ex : 2026-09-20 10:00)");
    if (when) setNotice(`Entretien à planifier le ${when} — à confirmer avec le backend une fois l'endpoint créé.`);
  }
  async function openPrintableDossier() {
    const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
    const criteriaRows = (candidate.analysis?.criteria || []).map((item) => `<tr><td>${escapeHtml(item.criterion)}</td><td>${escapeHtml(item.assessment)}${item.evidence ? `<br><small>${escapeHtml(item.evidence)}</small>` : ""}</td></tr>`).join("");
    const notesItems = (candidate.notes || []).map((note) => `<li>${escapeHtml(note)}</li>`).join("");
    // Les fichiers sont téléchargés ici, avant l'ouverture de la fenêtre (pendant que le
    // clic est encore "récent" pour le navigateur), et intégrés en local (blob) dans la
    // page imprimable. Objectif : que le clic sur "Télécharger" dans cette fenêtre ne
    // déclenche plus jamais de requête vers le serveur — seulement une sauvegarde locale
    // d'un fichier déjà en mémoire — pour éviter le blocage Chrome (about:blank#blocked)
    // des téléchargements initiés depuis une fenêtre ouverte par script.
    const filesItems = (await Promise.all((data.fichiers || []).map(async (file) => {
      const label = file.kind === "cv" ? "CV" : "Lettre de motivation";
      try {
        const response = await fetch(`${apiBaseUrl}/candidatures/${candidate.id}/fichiers/${file.id}`, { credentials: "include" });
        if (!response.ok) throw new Error();
        const blobUrl = URL.createObjectURL(await response.blob());
        return `<li>${label} — ${escapeHtml(file.original_name)} — <a download="${escapeHtml(file.original_name)}" href="${blobUrl}">Télécharger</a></li>`;
      } catch {
        return `<li>${label} — ${escapeHtml(file.original_name)} (échec du chargement, réessayez depuis l'onglet Profil)</li>`;
      }
    }))).join("");
    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>Dossier — ${escapeHtml(candidate.full_name)}</title>
      <style>
        body { font-family: "IBM Plex Sans", system-ui, sans-serif; color: #1c2620; max-width: 720px; margin: 2.5rem auto; padding: 0 1.5rem; line-height: 1.5; }
        h1 { font-family: "Space Grotesk", system-ui, sans-serif; margin-bottom: 0.15rem; }
        h2 { font-family: "Space Grotesk", system-ui, sans-serif; margin-top: 2rem; font-size: 1.05rem; border-bottom: 1px solid #d8ddd7; padding-bottom: 0.3rem; }
        .eyebrow { color: #5c6a63; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 0.5rem; }
        th, td { text-align: left; padding: 0.5rem; border-bottom: 1px solid #e5e9e3; vertical-align: top; }
        ul { padding-left: 1.2rem; }
        .print-actions { margin-top: 2rem; }
        @media print { .print-actions { display: none; } }
      </style></head><body>
      <h1>${escapeHtml(candidate.full_name)}</h1>
      <p class="eyebrow">${escapeHtml(candidate.job_title)} · ${escapeHtml(stageLabel)}</p>
      <h2>Coordonnées</h2>
      <table><tr><th>Email</th><td>${escapeHtml(candidate.email)}</td></tr><tr><th>Téléphone</th><td>${escapeHtml(candidate.phone || "—")}</td></tr><tr><th>Candidature reçue</th><td>${escapeHtml(humanDate(new Date(candidate.created_at)))}</td></tr></table>
      <h2>Documents</h2>
      <ul>${filesItems || "<li>Aucun document.</li>"}</ul>
      ${candidate.analysis ? `<h2>Analyse IA</h2><p>${escapeHtml(candidate.analysis.summary)}</p><table><thead><tr><th>Critère</th><th>Éléments relevés</th></tr></thead><tbody>${criteriaRows}</tbody></table><p><small>Analyse consultative — vérifiée par un RH.</small></p>` : ""}
      <h2>Notes RH</h2>
      <ul>${notesItems || "<li>Aucune note.</li>"}</ul>
      <div class="print-actions"><button onclick="window.print()">Imprimer</button></div>
      </body></html>`;
    const printWindow = window.open(URL.createObjectURL(new Blob([html], { type: "text/html" })), "_blank");
    if (!printWindow) {
      setNotice("Le navigateur a bloqué l'ouverture de la fenêtre d'impression.");
    }
  }
  const stageLabel = candidate.hr_decision === "to_review" || candidate.processing_status === "analysis_ready" ? "À examiner" : DECISION_LABELS[candidate.hr_decision] || "Nouveau";
  return <aside className="rh-detail">
    <button aria-label="Fermer le dossier" onClick={onClose} type="button"><span aria-hidden="true">←</span> Fermer</button>
    <div className="rh-detail-head"><div><h2>{candidate.full_name}</h2><p>{candidate.job_title}</p></div><button className="rh-text-action" onClick={openPrintableDossier} type="button">Voir le dossier ↗</button></div>
    <div className="rh-statuses"><span>{stageLabel}</span>{candidate.analysis ? <span>Analyse IA disponible</span> : null}</div>
    <div className="rh-tabs" role="tablist">
      <button aria-current={tab === "profil" ? "page" : undefined} className={tab === "profil" ? "is-active" : ""} onClick={() => setTab("profil")} role="tab" type="button">Profil</button>
      <button aria-current={tab === "analyse" ? "page" : undefined} className={tab === "analyse" ? "is-active" : ""} onClick={() => setTab("analyse")} role="tab" type="button">Analyse IA</button>
      <button aria-current={tab === "activite" ? "page" : undefined} className={tab === "activite" ? "is-active" : ""} onClick={() => setTab("activite")} role="tab" type="button">Activité</button>
    </div>
    {tab === "profil" ? <CandidateProfileTab apiBaseUrl={apiBaseUrl} candidate={candidate} files={data.fichiers} /> : null}
    {tab === "analyse" ? <CandidateAnalysisTab candidate={candidate} onRetry={retryAnalysis} pending={action === "retry"} /> : null}
    {tab === "activite" ? <CandidateActivityTab apiBaseUrl={apiBaseUrl} candidate={candidate} action={action} onDecide={decide} onSendDraft={sendEmail} draft={draft} setDraft={setDraft} eventsVersion={eventsVersion} onQuickNote={quickNote} onQuickInterview={quickInterview} /> : null}
    {notice ? <p role="status">{notice}</p> : null}
  </aside>;
}

function Candidates({ apiBaseUrl, candidates, offers, filters, nextCursor, onFiltersChange, refresh, loadMore, initialSelected, onConsumeInitialSelected }) {
  const [selected, setSelected] = useState(initialSelected || null);
  useEffect(() => { if (initialSelected) { setSelected(initialSelected); onConsumeInitialSelected?.(); } }, [initialSelected]);
  function setFilter(name, value) { onFiltersChange((current) => ({ ...current, [name]: value })); }
  return <section><div className="rh-heading"><div><p className="rh-eyebrow">Candidatures</p><h2>{candidates.length} candidatures · Mise à jour aujourd'hui</h2></div><button onClick={refresh} type="button">Actualiser</button></div>
    <div className="rh-form-grid rh-form-grid-3"><label>Offre<select value={filters.job_id} onChange={(event) => setFilter("job_id", event.target.value)}><option value="">Toutes les offres</option>{offers.map((offer) => <option key={offer.id} value={offer.id}>{offer.title}</option>)}</select></label><label>Traitement<select value={filters.processing_status} onChange={(event) => setFilter("processing_status", event.target.value)}><option value="">Tous les états</option>{["queued", "processing", "analysis_ready", "analysis_failed"].map((value) => <option key={value} value={value}>{value}</option>)}</select></label><label>Décision RH<select value={filters.hr_decision} onChange={(event) => setFilter("hr_decision", event.target.value)}><option value="">Toutes les décisions</option>{Object.entries(DECISION_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label></div>
    <div className={selected ? "rh-split" : "rh-split rh-split-collapsed"}>
      <div className="rh-table-wrap"><table><thead><tr><th>Candidat</th><th>Poste</th><th>Étape</th><th>IA</th><th>Dernière activité</th></tr></thead><tbody>{candidates.map((candidate) => <tr className={selected === candidate.id ? "is-selected" : ""} key={candidate.id} onClick={() => setSelected(candidate.id)}><td><strong>{candidate.full_name}</strong><small>{candidate.email}</small></td><td>{candidate.job_title}</td><td><i className={`rh-stage is-stage-${dashboardStage(candidate).replaceAll(" ", "-").toLowerCase()}`}>{dashboardStage(candidate)}</i></td><td>{candidate.processing_status === "analysis_ready" ? "Synthèse prête" : candidate.processing_status === "analysis_failed" ? "À vérifier" : "Disponible"}</td><td>{relativeDay(candidate.created_at)}</td></tr>)}</tbody></table>{candidates.length === 0 ? <p className="rh-empty">Aucune candidature ne correspond aux filtres.</p> : null}{nextCursor ? <button onClick={loadMore} type="button">Charger plus de candidatures</button> : null}</div>
      {selected ? <CandidateDetail apiBaseUrl={apiBaseUrl} candidateId={selected} onClose={() => setSelected(null)} refresh={refresh} /> : null}
    </div>
  </section>;
}

const PIPELINE_COLUMNS = [
  ["Nouveau", "mint"], ["À examiner", "amber"], ["Entretien", "blue"], ["En attente", "violet"]
];

function pipelineStage(candidate) {
  if (candidate.hr_decision === "to_review") return "Entretien";
  if (candidate.processing_status === "analysis_ready") return "À examiner";
  if (candidate.processing_status === "processing") return "En attente";
  return "Nouveau";
}

function Pipeline({ candidates, offers, onOpenCandidate }) {
  const [jobFilter, setJobFilter] = useState("");
  const filtered = jobFilter ? candidates.filter((candidate) => String(candidate.job_id) === jobFilter) : candidates;
  const columns = useMemo(() => PIPELINE_COLUMNS.map(([label, tone]) => [label, tone, filtered.filter((candidate) => pipelineStage(candidate) === label)]), [filtered]);
  return <section><div className="rh-heading"><div><p className="rh-eyebrow">Pipeline</p><h2>Suivi visuel des candidatures par étape.</h2></div></div>
    <div className="rh-form-grid rh-form-grid-2"><label>Offre<select value={jobFilter} onChange={(event) => setJobFilter(event.target.value)}><option value="">Toutes les offres</option>{offers.map((offer) => <option key={offer.id} value={offer.id}>{offer.title}</option>)}</select></label></div>
    <div className="rh-kanban">{columns.map(([label, tone, items]) => <div className="rh-kanban-column" key={label}>
      <div className="rh-kanban-head"><strong>{label}</strong><span className={`rh-badge is-${tone}`}>{items.length}</span></div>
      <div className="rh-kanban-cards">{items.map((candidate) => <button className="rh-kanban-card" key={candidate.id} onClick={() => onOpenCandidate(candidate.id)} type="button">
        <span className={`rh-avatar-dot is-${tone}`} aria-hidden="true" />
        <span className="rh-kanban-card-body"><strong>{candidate.full_name}</strong><small>{candidate.job_title}</small><small>{relativeDay(candidate.created_at)}</small></span>
      </button>)}{items.length === 0 ? <p className="rh-empty rh-empty-small">Aucune candidature.</p> : null}</div>
    </div>)}</div>
  </section>;
}

// L'API recrutement actuelle n'expose pas de route "équipe" (membres RH, charge de
// travail, présence). Ce tableau est une donnée de démonstration à remplacer par un
// vrai endpoint (ex: GET /equipe) — la structure ci-dessous correspond à ce que
// l'écran attend pour rester compatible avec un futur branchement API.
const TEAM_MEMBERS = [
  { id: 1, name: "Admin RH", role: "Admin RH", status: "online", offers: "Développeur·se full-stack + 2 autres", workload: 12, workloadUnit: "candidatures" },
  { id: 2, name: "Membre B", role: "Chargé·e de recrutement", status: "online", offers: "Responsable opérations + 1 autre", workload: 8, workloadUnit: "candidatures" },
  { id: 3, name: "Membre C", role: "Chargé·e de recrutement", status: "away", offers: "Support client + 1 autre", workload: 5, workloadUnit: "entretiens" },
  { id: 4, name: "Membre D", role: "Coordinateur RH", status: "online", offers: "Développeur·se full-stack", workload: 9, workloadUnit: "candidatures" },
  { id: 5, name: "Membre E", role: "Coordinateur RH", status: "online", offers: "Responsable opérations", workload: 4, workloadUnit: "entretiens" },
  { id: 6, name: "Membre F", role: "Chargé·e de recrutement", status: "away", offers: "Support client", workload: 6, workloadUnit: "candidatures" }
];

function Team({ candidates, offers }) {
  const totalCandidatures = candidates.length;
  const maxWorkload = Math.max(1, ...TEAM_MEMBERS.map((member) => member.workload));
  return <section><div className="rh-heading"><div><p className="rh-eyebrow">Équipe</p><h2>Équipe RH</h2><p>Gérez les membres de votre équipe et suivez leur activité.</p></div><button className="rh-primary" type="button">Inviter un membre</button></div>
    <div className="rh-metrics" aria-label="Indicateurs de l'équipe">
      <div className="rh-metric"><span className="rh-icon-disc is-mint" aria-hidden="true">♧</span><span className="rh-metric-copy"><span>Membres de l'équipe</span><strong>{TEAM_MEMBERS.length}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-blue" aria-hidden="true">▤</span><span className="rh-metric-copy"><span>Offres suivies</span><strong>{offers.length}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-mint" aria-hidden="true">▥</span><span className="rh-metric-copy"><span>Candidatures traitées</span><strong>{totalCandidatures}</strong></span></div>
      <div className="rh-metric"><span className="rh-icon-disc is-amber" aria-hidden="true">◷</span><span className="rh-metric-copy"><span>Entretiens réalisés</span><strong>{candidates.filter((candidate) => pipelineStage(candidate) === "Entretien").length}</strong></span></div>
    </div>
    <div className="rh-split rh-split-wide">
      <div className="rh-table-wrap"><table><thead><tr><th>Membre</th><th>Rôle</th><th>Offres suivies</th><th>Charge de travail</th><th></th></tr></thead><tbody>{TEAM_MEMBERS.map((member) => <tr key={member.id}><td><span className={`rh-status-dot is-${member.status}`} aria-hidden="true" /><strong>{member.name}</strong><small>{member.status === "online" ? "En ligne" : "Absent"}</small></td><td><span className="rh-badge is-mint">{member.role}</span></td><td>{member.offers}</td><td>{member.workload} {member.workloadUnit}<div className="rh-bar-track"><span style={{ width: `${(member.workload / maxWorkload) * 100}%` }} /></div></td><td><button type="button">•••</button></td></tr>)}</tbody></table></div>
      <aside className="rh-detail rh-detail-inline"><h3>Répartition des candidatures</h3><p>{totalCandidatures} candidatures au total</p><div className="rh-mini-bars">{TEAM_MEMBERS.map((member) => <div key={member.id}><span style={{ height: `${(member.workload / maxWorkload) * 100}%` }} /><small>{member.workload}</small><label>{member.name}</label></div>)}</div></aside>
    </div>
  </section>;
}

const EMPTY_CRITERIA = { technical: "", communication: "", experience: "", clarify: "" };

function AnalysisCriteriaSettings({ apiBaseUrl }) {
  const [values, setValues] = useState(EMPTY_CRITERIA);
  const [toggles, setToggles] = useState({ summaryOnly: true, requireHumanReview: true, hideIrrelevant: true });
  const [status, setStatus] = useState("");
  function set(name, value) { if (value.length <= 500) setValues((current) => ({ ...current, [name]: value })); }
  function toggle(name) { setToggles((current) => ({ ...current, [name]: !current[name] })); }
  async function save() {
    setStatus("Enregistrement…");
    try {
      // Endpoint proposé — à créer côté backend (aucune route de paramètres n'existe
      // encore dans packages/backend/src/routes.js).
      await apiRequest(apiBaseUrl, "/parametres/analyse-ia", { method: "PATCH", body: JSON.stringify({ criteria: values, options: toggles }) });
      setStatus("Modifications enregistrées.");
    } catch (error) {
      setStatus(error.status === 404 ? "Endpoint /parametres/analyse-ia à créer côté backend — rien n'a été sauvegardé." : error.message);
    }
  }
  const fields = [
    ["technical", "Compétences techniques attendues", "Ex. : langages, frameworks, outils, méthodologies, certifications…", "Listez les compétences techniques essentielles pour ce type de poste."],
    ["communication", "Compétences de communication", "Ex. : capacité à vulgariser, travail en équipe, aisance rédactionnelle, anglais…", "Précisez les compétences de communication et les soft skills importants."],
    ["experience", "Expérience liée au poste", "Ex. : nombre d'années, types de missions, secteurs d'activité, niveau de responsabilité…", "Décrivez le type d'expérience et les contextes pertinents pour ce poste."],
    ["clarify", "Points à clarifier lors de l'examen RH", "Ex. : disponibilité, mobilité, attentes salariales, cohérence du parcours, gaps à explorer…", "Indiquez les éléments sur lesquels l'équipe RH doit être particulièrement attentive."]
  ];
  return <div className="rh-split rh-split-settings">
    <form className="rh-editor" onSubmit={(event) => { event.preventDefault(); save(); }}>
      <h3>Critères d'analyse IA</h3><p>Définissez les critères utilisés par l'IA pour analyser et synthétiser les candidatures.</p>
      {fields.map(([name, label, placeholder, hint]) => <label key={name}>{label} *<textarea maxLength={500} onChange={(event) => set(name, event.target.value)} placeholder={placeholder} value={values[name]} /><small>{hint} — {values[name].length}/500</small></label>)}
      <div className="rh-inline"><button onClick={() => setValues(EMPTY_CRITERIA)} type="button">Réinitialiser</button><button className="rh-primary" type="submit">Enregistrer les modifications</button></div>
      {status ? <p role="status">{status}</p> : null}
    </form>
    <aside className="rh-detail rh-detail-inline">
      <div className="rh-info-box"><p><strong>À propos de l'analyse IA</strong></p><p>L'analyse des candidatures par l'IA est strictement consultative et fait toujours l'objet d'une revue humaine par l'équipe RH.</p><p>Les critères doivent être explicitement liés au poste concerné et non discriminatoires. L'IA aide à organiser et synthétiser l'information, mais ne prend aucune décision de recrutement.</p><p>La décision finale revient toujours aux personnes en charge du recrutement.</p></div>
      <h3>Options de contrôle</h3><p>Définissez la manière dont l'analyse IA est affichée et utilisée dans votre organisation.</p>
      <label className="rh-switch"><input checked={toggles.summaryOnly} onChange={() => toggle("summaryOnly")} type="checkbox" /><span><strong>Afficher uniquement une synthèse consultative</strong><small>L'IA fournit une synthèse des informations clés, sans recommandation prescriptive.</small></span></label>
      <label className="rh-switch"><input checked={toggles.requireHumanReview} onChange={() => toggle("requireHumanReview")} type="checkbox" /><span><strong>Exiger une vérification humaine avant toute action RH</strong><small>Toute action liée à une candidature nécessite une revue humaine préalable.</small></span></label>
      <label className="rh-switch"><input checked={toggles.hideIrrelevant} onChange={() => toggle("hideIrrelevant")} type="checkbox" /><span><strong>Masquer toute donnée non pertinente au poste</strong><small>L'analyse se limite aux informations en lien avec les critères définis pour le poste.</small></span></label>
    </aside>
  </div>;
}

const SETTINGS_TABS = [["general", "Général"], ["stages", "Étapes du pipeline"], ["ai", "Critères d'analyse IA"], ["retention", "Conservation des données"]];

function Settings({ apiBaseUrl }) {
  const [tab, setTab] = useState("ai");
  return <section><div className="rh-heading"><div><p className="rh-eyebrow">Paramètres</p><h2>Paramètres du recrutement</h2><p>Configurez les paramètres de votre processus de recrutement chez TechZone Recrutement.</p></div></div>
    <div className="rh-tabs rh-tabs-underline" role="tablist">{SETTINGS_TABS.map(([id, label]) => <button aria-current={tab === id ? "page" : undefined} className={tab === id ? "is-active" : ""} key={id} onClick={() => setTab(id)} role="tab" type="button">{label}</button>)}</div>
    {tab === "ai" ? <AnalysisCriteriaSettings apiBaseUrl={apiBaseUrl} /> : <p className="rh-empty">Cette section n'est pas encore branchée sur l'API — écran à construire avec le backend correspondant.</p>}
  </section>;
}

function Dashboard({ candidates, onOpenCandidates }) {
  const stages = useMemo(() => candidates.reduce((all, candidate) => {
    all[dashboardStage(candidate)] += 1;
    return all;
  }, { "Nouveau": 0, "À examiner": 0, "Entretien": 0, "En attente": 0 }), [candidates]);
  const recent = useMemo(() => candidates.slice(0, 3), [candidates]);
  const bars = useMemo(() => Array.from({ length: 30 }, (_, index) => {
    const daysAgo = 29 - index;
    return candidates.filter((candidate) => Math.floor((Date.now() - new Date(candidate.created_at).getTime()) / 86400000) === daysAgo).length;
  }), [candidates]);
  const maxBar = Math.max(1, ...bars);
  const metrics = [
    ["À examiner", stages["À examiner"], "Dossiers nécessitant une revue RH", "▧", "mint"],
    ["Entretiens", stages.Entretien, "Étape non renseignée par l'API", "♧", "blue"],
    ["Analyse IA disponible", candidates.filter((candidate) => candidate.processing_status === "analysis_ready").length, "À vérifier par un RH", "✦", "mint"],
    ["Délai moyen", "—", "Mesure indisponible", "◷", "amber"]
  ];
  return <section className="rh-dashboard" aria-labelledby="dashboard-title">
    <div className="rh-dashboard-heading"><div><h2 id="dashboard-title">Vue d'ensemble</h2><p>Un aperçu de votre activité de recrutement chez TechZone Recrutement.</p></div><time dateTime={new Date().toISOString()}>{`Aujourd'hui, le ${humanDate(new Date())}`}</time></div>
    <div className="rh-metrics" aria-label="Indicateurs de recrutement">{metrics.map(([label, value, detail, icon, tone]) => <button className="rh-metric" key={label} onClick={onOpenCandidates} type="button"><span className={`rh-icon-disc is-${tone}`} aria-hidden="true">{icon}</span><span className="rh-metric-copy"><span>{label}</span><strong>{value}</strong><small>{detail}</small></span><span className="rh-metric-arrow" aria-hidden="true">›</span></button>)}</div>
    <div className="rh-dashboard-grid"><section className="rh-panel rh-volume" aria-labelledby="volume-title"><div className="rh-panel-heading"><h3 id="volume-title">Volume de candidatures <span>(30 derniers jours)</span></h3><button type="button">30 derniers jours <span aria-hidden="true">⌄</span></button></div><div className="rh-chart" role="img" aria-label={`Histogramme des candidatures sur les 30 derniers jours, maximum ${maxBar} candidature(s) par jour.`}><div className="rh-chart-scale"><span>{maxBar}</span><span>{Math.ceil(maxBar / 2)}</span><span>0</span></div><div className="rh-bars">{bars.map((value, index) => <span className="rh-bar" key={index} style={{ height: `${value ? Math.max(12, value / maxBar * 100) : 2}%` }} title={`${value} candidature${value > 1 ? "s" : ""}`} />)}</div></div><div className="rh-chart-labels"><span>Il y a 30 j.</span><span>Aujourd'hui</span></div></section><section className="rh-panel rh-pipeline" aria-labelledby="pipeline-title"><div className="rh-panel-heading"><div><h3 id="pipeline-title">Pipeline de candidatures</h3><p>Répartition des candidatures par étape du processus.</p></div></div><div className="rh-pipeline-steps">{Object.entries(stages).map(([label, count], index) => <div className="rh-pipeline-step" key={label}><span className={`rh-icon-disc is-step-${index}`} aria-hidden="true">{["▧", "⌕", "♧", "◷"][index]}</span><strong>{label}</strong><b>{count}</b>{index < 3 ? <span className="rh-step-arrow" aria-hidden="true">›</span> : null}</div>)}</div></section></div>
    <section className="rh-panel rh-todo" aria-labelledby="todo-title"><div className="rh-panel-heading"><div><h3 id="todo-title">À traiter aujourd'hui</h3><p>{recent.length ? `${recent.length} élément${recent.length > 1 ? "s" : ""} nécessitent votre attention.` : "Aucun élément à traiter."}</p></div><button className="rh-text-action" onClick={onOpenCandidates} type="button">Voir toutes les candidatures <span aria-hidden="true">→</span></button></div>{recent.length ? <div className="rh-todo-table" role="table" aria-label="Candidatures à traiter"><div className="rh-todo-head" role="row"><span role="columnheader">Candidat·e</span><span role="columnheader">Poste</span><span role="columnheader">Étape</span><span role="columnheader">Actions</span></div>{recent.map((candidate, index) => { const stage = dashboardStage(candidate); return <div className="rh-todo-row" key={candidate.id} role="row"><div role="cell" className={`rh-avatar is-avatar-${index}`}><span aria-hidden="true">●</span><p><strong>{candidate.full_name}</strong><small>Reçu le {humanDate(new Date(candidate.created_at))}</small></p></div><span role="cell">{candidate.job_title}</span><span role="cell"><i className={`rh-stage is-stage-${stage.replaceAll(" ", "-").toLowerCase()}`}>{stage}</i></span><div role="cell" className="rh-todo-actions"><button className="rh-primary" onClick={onOpenCandidates} type="button">Ouvrir</button><button onClick={onOpenCandidates} type="button">Ajouter une note</button><button className="rh-more" aria-label={`Plus d'actions pour ${candidate.full_name}`} type="button">•••</button></div></div>; })}</div> : <div className="rh-empty"><p>Les nouvelles candidatures apparaîtront ici, sans classement automatique.</p><button className="rh-primary" onClick={onOpenCandidates} type="button">Voir les candidatures</button></div>}</section>
  </section>;
}

function AdminLogin({ apiBaseUrl, onAuthenticated }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  async function submit(event) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      await apiRequest(apiBaseUrl, "/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      onAuthenticated();
    } catch (caught) {
      setError(caught.message);
    } finally {
      setPending(false);
    }
  }
  return <main className="rh-login"><form onSubmit={submit}><p className="rh-eyebrow">TECH ZONE · RECETTE ISOLÉE</p><h1>Accès RH</h1><p>Utilisez votre compte administrateur TechZone existant. Aucun compte recrutement distinct n'est créé.</p><label>Email administrateur<input autoComplete="username" onChange={(event) => setEmail(event.target.value)} required type="email" value={email} /></label><label>Mot de passe<input autoComplete="current-password" onChange={(event) => setPassword(event.target.value)} required type="password" value={password} /></label>{error ? <p className="rh-error" role="alert">{error}</p> : null}<button className="rh-primary" disabled={pending} type="submit">{pending ? "Connexion…" : "Ouvrir le tableau de bord"}</button></form></main>;
}

const NAVIGATION = [
  ["dashboard", "⌂", "Tableau de bord"], ["offers", "▤", "Offres"], ["candidates", "♧", "Candidatures"],
  ["pipeline", "▥", "Pipeline"], ["team", "♧", "Équipe"], ["settings", "⚙", "Paramètres"]
];

function humanDate(value) {
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", year: "numeric" }).format(value);
}

function dashboardStage(candidate) {
  if (candidate.hr_decision === "to_review" || candidate.processing_status === "analysis_ready") return "À examiner";
  if (candidate.processing_status === "processing") return "En attente";
  return "Nouveau";
}

export function RecruitmentAdminPanel({ apiBaseUrl = "/api/admin/recrutement" }) {
  const [tab, setTab] = useState("dashboard");
  const [pendingCandidateId, setPendingCandidateId] = useState(null);
  const [filters, setFilters] = useState({ job_id: "", processing_status: "", hr_decision: "" });
  const [state, setState] = useState({ offers: [], candidates: [], nextCursor: null, loading: true, error: "", authRequired: false });
  function queryString(cursor = null) { return new URLSearchParams([...Object.entries(filters).filter(([, value]) => value), ...(cursor ? [["cursor", cursor]] : [])]).toString(); }
  async function refresh() { try { const query = queryString(); const [offers, candidates] = await Promise.all([apiRequest(apiBaseUrl, "/offres"), apiRequest(apiBaseUrl, `/candidatures?${query}`)]); setState({ offers: offers.offres, candidates: candidates.candidatures, nextCursor: candidates.pagination.next_cursor, loading: false, error: "", authRequired: false }); } catch (error) { setState((current) => ({ ...current, loading: false, error: error.status === 401 ? "" : error.message, authRequired: error.status === 401 })); } }
  async function loadMore() { if (!state.nextCursor) return; try { const candidates = await apiRequest(apiBaseUrl, `/candidatures?${queryString(state.nextCursor)}`); setState((current) => ({ ...current, candidates: [...current.candidates, ...candidates.candidatures], nextCursor: candidates.pagination.next_cursor })); } catch (error) { setState((current) => ({ ...current, error: error.message })); } }
  useEffect(() => { refresh(); }, [apiBaseUrl, filters]);
  function openCandidateInPipeline(id) { setPendingCandidateId(id); setTab("candidates"); }
  const currentLabel = NAVIGATION.find(([id]) => id === tab)?.[2] || "Tableau de bord";
  if (state.authRequired) return <AdminLogin apiBaseUrl={apiBaseUrl} onAuthenticated={refresh} />;
  return <div className="rh-module"><aside className="rh-sidebar"><a className="rh-brand" href="/admin/recrutement" aria-label="TechZone Recrutement, tableau de bord"><span className="rh-brand-mark" aria-hidden="true">✦</span><span>TechZone<br /><strong>Recrutement</strong></span></a><nav aria-label="Navigation du recrutement">{NAVIGATION.map(([id, icon, label]) => <button aria-current={tab === id ? "page" : undefined} className={tab === id ? "is-active" : ""} key={id} onClick={() => setTab(id)} type="button"><span aria-hidden="true">{icon}</span>{label}</button>)}</nav><div className="rh-user"><span className="rh-user-avatar" aria-hidden="true">●</span><span>Admin RH</span><span aria-hidden="true">›</span></div></aside><div className="rh-workspace"><header className="rh-topbar"><p><span>Accueil</span><b aria-hidden="true">›</b> <strong>{currentLabel}</strong></p><div><label className="rh-search"><span aria-hidden="true">⌕</span><input aria-label="Recherche globale" placeholder="Rechercher une offre, un·e candidat·e…" /></label><button type="button">⇩ <span>Exporter</span></button><button className="rh-primary rh-new-job" onClick={() => setTab("offers")} type="button">＋ Nouvelle offre</button><button className="rh-notification" aria-label="Notifications" type="button">♧<i /></button></div></header>{state.loading ? <p className="rh-loading">Chargement…</p> : null}{state.error ? <p className="rh-error" role="alert">{state.error}</p> : null}
    {!state.loading && !state.error && tab === "dashboard" ? <Dashboard candidates={state.candidates} onOpenCandidates={() => setTab("candidates")} /> : null}
    {!state.loading && !state.error && tab === "candidates" ? <Candidates apiBaseUrl={apiBaseUrl} candidates={state.candidates} offers={state.offers} filters={filters} nextCursor={state.nextCursor} onFiltersChange={setFilters} refresh={refresh} loadMore={loadMore} initialSelected={pendingCandidateId} onConsumeInitialSelected={() => setPendingCandidateId(null)} /> : null}
    {!state.loading && !state.error && tab === "offers" ? <Offers apiBaseUrl={apiBaseUrl} offers={state.offers} refresh={refresh} /> : null}
    {!state.loading && !state.error && tab === "pipeline" ? <Pipeline candidates={state.candidates} offers={state.offers} onOpenCandidate={openCandidateInPipeline} /> : null}
    {!state.loading && !state.error && tab === "team" ? <Team candidates={state.candidates} offers={state.offers} /> : null}
    {!state.loading && !state.error && tab === "settings" ? <Settings apiBaseUrl={apiBaseUrl} /> : null}
  </div></div>;
}

export { RichEditor };