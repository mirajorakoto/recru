import { render, screen } from "@testing-library/react";
import { expect, test } from "vitest";
import { RichEditor } from "./index";

test("offers only the approved rich-text controls", () => {
  render(<RichEditor value="<p>Bonjour</p>" onChange={() => {}} />);
  expect(screen.getByRole("button", { name: "G" })).toBeInTheDocument();
  expect(screen.getAllByRole("button", { name: /liste/i })).toHaveLength(2);
  expect(screen.getByRole("textbox")).toBeInTheDocument();
});
