import { render, screen } from "@testing-library/react";
import { afterEach, expect, test, vi } from "vitest";
import { PIPELINE_STATUSES, RecruitmentAdminPanel, RichEditor, ScorePanel } from "./index";

afterEach(() => vi.unstubAllGlobals());

test("offers only the approved rich-text controls", () => {
  render(<RichEditor value="<p>Bonjour</p>" onChange={() => {}} />);
  expect(screen.getByRole("button", { name: "G" })).toBeInTheDocument();
  expect(screen.getAllByRole("button", { name: /liste/i })).toHaveLength(2);
  expect(screen.getByRole("textbox")).toBeInTheDocument();
});

test("exposes the nine pipeline stages of the specification", () => {
  expect(PIPELINE_STATUSES.map(([value]) => value)).toEqual([
    "nouvelle", "en_analyse", "cv_analyse", "preselectionnee", "entretien",
    "evaluation", "en_attente", "acceptee", "refusee"
  ]);
});

test("explains the AI score: components, matches, gaps and the human-review notice", () => {
  const analysis = {
    recommendation: "strong_match",
    score: { total: 83, components: [{ category: "competence", points: 36, max: 40 }, { category: "formation", points: 15, max: 15 }], disclaimer: "Indicateur d'aide, vérification humaine nécessaire." },
    criteria: [
      { criterion: "Java", assessment: "supported" },
      { criterion: "React", assessment: "not_found" },
      { criterion: "Docker", assessment: "uncertain" }
    ],
    profile: { experience_years: 2, highest_education_level: "bac+3" }
  };
  render(<ScorePanel analysis={analysis} />);
  expect(screen.getByText("Forte correspondance")).toBeInTheDocument();
  expect(screen.getByText("✓ Java")).toBeInTheDocument();
  expect(screen.getByText("✗ React")).toBeInTheDocument();
  expect(screen.getByText(/Docker \(à confirmer\)/)).toBeInTheDocument();
  expect(screen.getByText("36/40")).toBeInTheDocument();
  expect(screen.getByText(/vérification humaine/i)).toBeInTheDocument();
});

test("hides write actions and admin sections for the read-only role", async () => {
  const jobs = { offres: [{ id: 1, title: "Dev", slug: "dev", status: "draft", criteria: [] }] };
  const routes = {
    "/moi": { email: "lect@x.mg", display_name: "Lecteur", role: "lecteur" },
    "/offres": jobs,
    "/candidatures": { candidatures: [], pagination: { next_cursor: null } },
    "/tableau-de-bord": { totals: {}, alertes: {} }
  };
  vi.stubGlobal("fetch", vi.fn(async (url) => {
    const path = String(url).replace("/api/admin/recrutement", "").split("?")[0];
    return routes[path] ? { ok: true, status: 200, json: async () => routes[path] } : { ok: false, status: 404, json: async () => ({ error: "nf" }) };
  }));
  render(<RecruitmentAdminPanel apiBaseUrl="/api/admin/recrutement" />);
  expect(await screen.findByText("Lecteur (lecture seule)")).toBeInTheDocument();
  expect(screen.queryByRole("button", { name: /Nouvelle offre/ })).toBeNull();
  expect(screen.queryByText("Journal")).toBeNull();
  expect(screen.queryByText("Équipe")).toBeNull();
});

test("shows the login form when the API answers 401", async () => {
  vi.stubGlobal("fetch", vi.fn(async () => ({ ok: false, status: 401, json: async () => ({ error: "Authentification requise" }) })));
  render(<RecruitmentAdminPanel apiBaseUrl="/api/admin/recrutement" />);
  expect(await screen.findByText("Accès RH")).toBeInTheDocument();
});
